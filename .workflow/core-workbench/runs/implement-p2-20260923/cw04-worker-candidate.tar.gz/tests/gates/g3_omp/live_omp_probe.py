"""Start real OMP 18.2.10 processes, load the G3 extension, and exercise API acceptance.

No prompt is submitted to either of the TUI instances. `sendUserMessage` uses the
public `nextTurn` queue without triggering a provider request. A separate, single
read-only `--print` request can be run with `--auth-probe`.
"""

from __future__ import annotations

import argparse
import fcntl
import json
import os
from pathlib import Path
import pty
import select
import shutil
import signal
import socket
import socketserver
import struct
import subprocess
import sys
import tempfile
import termios
import threading
import time
from uuid import uuid4

REPO = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO / "src"))

from workbench.contracts.v1 import ActorRole, ControlEnvelope, MessageEvent, MessageKind

OMP_VERSION = "omp/18.2.10"
EXTENSION = REPO / "omp_bridge" / "g3" / "bridge.ts"


class BridgeHarness(socketserver.ThreadingUnixStreamServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, socket_path: Path, tokens: dict[str, str]):
        self.tokens = tokens
        self.condition = threading.Condition()
        self.peers: dict[str, dict[str, object]] = {}
        self.acks: dict[str, dict[str, object]] = {}
        self.events: list[dict[str, object]] = []
        self.dropped_ack_ids: set[str] = set()
        super().__init__(str(socket_path), PeerHandler)

    def peer(self, role: str, timeout: float = 20) -> dict[str, object]:
        deadline = time.monotonic() + timeout
        with self.condition:
            while role not in self.peers and time.monotonic() < deadline:
                self.condition.wait(deadline - time.monotonic())
            if role not in self.peers:
                raise TimeoutError(f"OMP extension did not connect for role={role}")
            return self.peers[role]

    def request(self, role: str, message: dict[str, object], timeout: float = 5) -> dict[str, object]:
        peer = self.peer(role)
        request_id = str(uuid4())
        frame = {**message, "requestId": request_id}
        with peer["write_lock"]:  # type: ignore[index]
            peer["socket"].sendall((json.dumps(frame) + "\n").encode())  # type: ignore[index,union-attr]
        deadline = time.monotonic() + timeout
        with self.condition:
            while request_id not in self.acks and time.monotonic() < deadline:
                self.condition.wait(deadline - time.monotonic())
            result = self.acks.pop(request_id, None)
        if result is None:
            raise TimeoutError(f"extension did not acknowledge {message.get('kind')}")
        return result


class PeerHandler(socketserver.StreamRequestHandler):
    server: BridgeHarness

    def _write(self, value: dict[str, object]) -> None:
        self.wfile.write((json.dumps(value) + "\n").encode())
        self.wfile.flush()

    def handle(self) -> None:
        try:
            hello = json.loads(self.rfile.readline(65537))
            if not isinstance(hello, dict) or hello.get("kind") != "hello":
                return
            role = hello.get("role")
            if role not in self.server.tokens or hello.get("token") != self.server.tokens[role]:
                return
            session_id = hello.get("ompSessionId")
            generation = hello.get("generation")
            pid = hello.get("pid")
            if not isinstance(session_id, str) or not isinstance(generation, int) or not isinstance(pid, int):
                return
            with self.server.condition:
                peer = {
                    "role": role,
                    "session_id": session_id,
                    "generation": generation,
                    "pid": pid,
                    "socket": self.request,
                    "write_lock": threading.Lock(),
                    "hello": hello,
                    "state": {},
                }
                self.server.peers[role] = peer
                self.server.condition.notify_all()
            self._write({"kind": "ready", "sessionId": session_id, "generation": generation})
            while True:
                raw = self.rfile.readline(65537)
                if not raw:
                    break
                frame = json.loads(raw)
                if not isinstance(frame, dict):
                    continue
                kind = frame.get("kind")
                with self.server.condition:
                    if kind == "state":
                        peer["state"] = frame
                    elif kind == "api_ack" and isinstance(frame.get("requestId"), str):
                        request_id = frame["requestId"]
                        if request_id not in self.server.dropped_ack_ids:
                            self.server.acks[request_id] = frame
                    elif kind == "omp_event":
                        self.server.events.append({
                            "role": role,
                            "name": frame.get("name"),
                            "toolName": frame.get("toolName"),
                        })
                    self.server.condition.notify_all()
        except (ConnectionError, OSError, ValueError, json.JSONDecodeError):
            return
        finally:
            try:
                with self.server.condition:
                    current = self.server.peers.get(str(locals().get("role", "")))
                    if current and current.get("socket") is self.request:
                        self.server.peers.pop(str(role), None)
                    self.server.condition.notify_all()
            except Exception:
                pass


def _omp_version(omp: str) -> str:
    result = subprocess.run([omp, "--version"], text=True, capture_output=True, timeout=10, check=False)
    return (result.stdout + result.stderr).strip().splitlines()[0] if result.returncode == 0 else "unknown"


def _start_omp(omp: str, role: str, token: str, root: Path, socket_path: Path, config: Path) -> dict[str, object]:
    cwd = root / f"cwd-{role}"
    session_dir = root / f"sessions-{role}"
    cwd.mkdir()
    session_dir.mkdir()
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(cwd)
        fcntl.ioctl(0, termios.TIOCSWINSZ, struct.pack("HHHH", 30, 100, 0, 0))
        env = dict(os.environ)
        env.update({
            "TERM": "xterm-256color",
            "LANG": "C.UTF-8",
            "COLORTERM": "truecolor",
            "WORKBENCH_G3_BRIDGE_SOCKET": str(socket_path),
            "WORKBENCH_G3_ROLE": role,
            "WORKBENCH_G3_TOKEN": token,
            "WORKBENCH_G3_GENERATION": "1",
            "WORKBENCH_G3_EXPECTED_OMP_VERSION": OMP_VERSION,
        })
        args = [
            omp,
            "--no-session",
            "--no-pty",
            "--no-skills",
            "--no-rules",
            "--no-title",
            "--no-extensions",
            "--extension",
            str(EXTENSION),
            "--cwd",
            str(cwd),
            "--session-dir",
            str(session_dir),
            "--config",
            str(config),
        ]
        os.execvpe(omp, args, env)
    os.set_blocking(fd, False)
    return {"pid": pid, "fd": fd, "role": role, "pty_bytes": 0}


def _stop_omps(children: list[dict[str, object]]) -> None:
    for child in children:
        try:
            os.killpg(int(child["pid"]), signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + 3
    remaining = {int(child["pid"]) for child in children}
    while remaining and time.monotonic() < deadline:
        for pid in tuple(remaining):
            try:
                os.waitpid(pid, os.WNOHANG)
                if not Path(f"/proc/{pid}").exists():
                    remaining.discard(pid)
            except ChildProcessError:
                remaining.discard(pid)
        time.sleep(0.03)
    for pid in remaining:
        try:
            os.killpg(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    for child in children:
        try:
            os.close(int(child["fd"]))
        except OSError:
            pass


def _run_pair(omp: str, pair_name: str, kinds: tuple[MessageKind, MessageKind]) -> list[dict[str, object]]:
    with tempfile.TemporaryDirectory(prefix=f"cw04-g3-{pair_name}-") as temp:
        root = Path(temp)
        socket_path = root / "bridge.sock"
        config = root / "config.yml"
        config.write_text("# Isolated per-probe settings overlay.\n", encoding="utf-8")
        roles = ("manager", "worker")
        tokens = {role: str(uuid4()) for role in roles}
        server = BridgeHarness(socket_path, tokens)
        os.chmod(socket_path, 0o600)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        children: list[dict[str, object]] = []
        try:
            for role in roles:
                children.append(_start_omp(omp, role, tokens[role], root, socket_path, config))
            peers = {role: server.peer(role) for role in roles}
            if len({int(peers[role]["pid"]) for role in roles}) != 2:
                raise RuntimeError("two independent OMP PIDs were not observed")
            for role in roles:
                state_ack = server.request(role, {"kind": "probe"})
                if state_ack.get("status") != "state":
                    raise RuntimeError(f"OMP state probe failed for {role}")
                state = state_ack.get("state")
                if not isinstance(state, dict) or state.get("idle") is not True or state.get("editorEmpty") is not True:
                    raise RuntimeError(f"OMP session did not report idle/empty composer for {role}")

            task_id, revision_id, run_id = str(uuid4()), str(uuid4()), str(uuid4())
            messages: list[tuple[str, MessageKind, ActorRole]] = []
            if pair_name == "task-answer":
                messages = [("worker", kinds[0], ActorRole.MANAGER), ("manager", kinds[1], ActorRole.WORKER)]
            else:
                messages = [("worker", kinds[0], ActorRole.MANAGER), ("manager", kinds[1], ActorRole.WORKER)]
            for target, kind, sender_role in messages:
                peer = peers[target]
                envelope = ControlEnvelope(
                    message_id=str(uuid4()),
                    delivery_attempt_id=str(uuid4()),
                    sender_role=sender_role,
                    session_id=str(peer["session_id"]),
                    session_generation=int(peer["generation"]),
                    task_id=task_id,
                    revision_id=revision_id,
                    run_id=run_id,
                    event=MessageEvent(kind, {"text": f"G3 {kind.value} probe"}),
                )
                response = server.request(target, {"kind": "deliver", "envelope": envelope.to_json()})
                if response.get("status") != "api_accepted" or response.get("modelProcessed") is not False:
                    raise RuntimeError(
                        "OMP public delivery did not reach API acceptance for "
                        f"{target}/{kind.value}: status={response.get('status')!r}, "
                        f"reason={response.get('reason')!r}"
                    )
            result = []
            for role in roles:
                peer = peers[role]
                result.append({
                    "role": role,
                    "omp_session_id": peer["session_id"],
                    "session_generation": peer["generation"],
                    "pid": peer["pid"],
                    "message_api_acceptance": "pass",
                    "model_processing": "not_triggered_by_design",
                })
            return result
        finally:
            _stop_omps(children)
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)


def auth_probe(omp: str) -> int:
    """Make exactly one non-tool, read-only model request and print no response body."""
    with tempfile.TemporaryDirectory(prefix="cw04-g3-auth-") as temp:
        root = Path(temp)
        cwd, session_dir = root / "cwd", root / "sessions"
        cwd.mkdir()
        session_dir.mkdir()
        config = root / "config.yml"
        config.write_text("# Temporary settings overlay.\n", encoding="utf-8")
        command = [
            omp,
            "--print",
            "--no-session",
            "--no-tools",
            "--no-pty",
            "--no-extensions",
            "--no-skills",
            "--no-rules",
            "--no-title",
            "--cwd",
            str(cwd),
            "--session-dir",
            str(session_dir),
            "--config",
            str(config),
            "Reply exactly G3_AUTH_PROBE_OK and no other text.",
        ]
        result = subprocess.run(command, cwd=cwd, text=True, capture_output=True, timeout=75, check=False)
        print(f"auth_probe_exit={result.returncode} exact_marker={'yes' if 'G3_AUTH_PROBE_OK' in result.stdout else 'no'}")
        return 0 if result.returncode == 0 and "G3_AUTH_PROBE_OK" in result.stdout else 1


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--auth-probe", action="store_true", help="send exactly one read-only model request")
    args = parser.parse_args()
    omp = shutil.which("omp")
    if not omp:
        print("OMP is not installed", file=sys.stderr)
        return 2
    version = _omp_version(omp)
    if version != OMP_VERSION:
        print(f"expected {OMP_VERSION}; found {version}", file=sys.stderr)
        return 2
    if args.auth_probe:
        return auth_probe(omp)
    result = []
    result.extend(_run_pair(omp, "task-answer", (MessageKind.TASK, MessageKind.ANSWER)))
    result.extend(_run_pair(omp, "question-report", (MessageKind.QUESTION, MessageKind.REPORT)))
    print(json.dumps({"omp_version": version, "pairs": result, "provider_requests_from_tui": 0}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
