import net from "node:net";
import { parseControlEnvelope } from "../contract/v1.ts";

type Role = "manager" | "worker";
type Frame = Record<string, unknown>;

const READ_ONLY_TOOLS = new Set(["read", "grep", "glob"]);

function env(name: string): string {
	const value = process.env[name];
	if (!value) throw new Error(`missing ${name}`);
	return value;
}

function sendLine(socket: net.Socket, value: Frame): void {
	if (!socket.destroyed) socket.write(`${JSON.stringify(value)}\n`);
}

function roleAllows(role: Role, senderRole: string, kind: string): boolean {
	return role === "worker"
		? senderRole === "manager" && (kind === "task" || kind === "question")
		: senderRole === "worker" && (kind === "answer" || kind === "report");
}

export default function workbenchG3Extension(pi: any): void {
	const socketPath = env("WORKBENCH_G3_BRIDGE_SOCKET");
	const role = env("WORKBENCH_G3_ROLE") as Role;
	const token = env("WORKBENCH_G3_TOKEN");
	let generation = Number(env("WORKBENCH_G3_GENERATION"));
	if ((role !== "manager" && role !== "worker") || !Number.isSafeInteger(generation) || generation < 1) {
		throw new Error("invalid G3 role or session generation");
	}

	let socket: net.Socket | undefined;
	let context: any;
	let ompSessionId = "";
	let paused = false;
	let connected = false;
	let inbound = "";
	const seen = new Map<string, "sending" | "api_accepted" | "unknown">();
	const approvals = new Set<string>();
	const mutableCalls = new Set<string>();

	function snapshot(): Frame {
		let editorText: string | undefined;
		try {
			editorText = context?.ui?.getEditorText?.();
		} catch {
			editorText = undefined;
		}
		let idle = false;
		let pending = true;
		try {
			idle = context?.isIdle?.() === true;
			pending = context?.hasPendingMessages?.() !== false;
		} catch {
			// Unknown state remains fail-closed.
		}
		return {
			kind: "state",
			role,
			sessionId: ompSessionId,
			generation,
			idle,
			pending,
			approvalPending: approvals.size > 0,
			inFlightMutationCount: mutableCalls.size,
			editorKnown: typeof editorText === "string",
			editorEmpty: editorText === "",
			editorLength: typeof editorText === "string" ? editorText.length : null,
			paused,
		};
	}

	function publishState(): void {
		if (connected) sendLine(socket!, snapshot());
	}

	function acknowledge(requestId: string, status: string, extra: Frame = {}): void {
		sendLine(socket!, { kind: "api_ack", requestId, status, ...extra });
	}

	function sendEvent(name: string, fields: Frame = {}): void {
		if (!connected) return;
		sendLine(socket!, { kind: "omp_event", name, sessionId: ompSessionId, generation, ...fields });
	}

	function isMessageSafe(): boolean {
		const state = snapshot();
		return state.idle === true
			&& state.pending === false
			&& state.approvalPending === false
			&& state.editorKnown === true
			&& state.editorEmpty === true
			&& mutableCalls.size === 0;
	}

	async function handle(frame: Frame): Promise<void> {
		if (frame.kind === "probe" && typeof frame.requestId === "string") {
			acknowledge(frame.requestId, "state", { state: snapshot() });
			return;
		}
		if (frame.kind === "pause" && typeof frame.requestId === "string") {
			paused = true;
			const complete = mutableCalls.size === 0;
			acknowledge(frame.requestId, complete ? "paused" : "pause_waiting", {
				inFlightMutationCount: mutableCalls.size,
				approvalPendingCount: approvals.size,
			});
			publishState();
			return;
		}
		if (frame.kind !== "deliver" || typeof frame.requestId !== "string" || typeof frame.envelope !== "string") return;

		const requestId = frame.requestId;
		let envelope: ReturnType<typeof parseControlEnvelope>;
		try {
			envelope = parseControlEnvelope(JSON.parse(frame.envelope) as unknown, {
				sessionId: ompSessionId,
				sessionGeneration: generation,
			});
		} catch (error) {
			acknowledge(requestId, "rejected", { reason: error instanceof Error ? error.message : "invalid envelope" });
			return;
		}
		if (envelope.event.type !== "message" || !roleAllows(role, envelope.senderRole, envelope.event.messageKind)) {
			acknowledge(requestId, "rejected", { reason: "role/kind does not match target OMP session" });
			return;
		}
		const messageIdentity = `${envelope.sessionId}:${envelope.sessionGeneration}:${envelope.messageId}`;
		const prior = seen.get(messageIdentity);
		if (prior === "api_accepted") {
			acknowledge(requestId, "duplicate_api_accepted", { messageId: envelope.messageId });
			return;
		}
		if (prior === "unknown" || prior === "sending") {
			acknowledge(requestId, "unknown_no_replay", { messageId: envelope.messageId });
			return;
		}
		if (!isMessageSafe()) {
			acknowledge(requestId, "deferred", { reason: "OMP is busy, has pending work/approval, or composer state is unsafe" });
			publishState();
			return;
		}

		seen.set(messageIdentity, "sending");
		const message = {
			workbench_message_id: envelope.messageId,
			workbench_delivery_attempt_id: envelope.deliveryAttemptId,
			kind: envelope.event.messageKind,
			task_id: envelope.taskId,
			revision_id: envelope.revisionId,
			run_id: envelope.runId,
			payload: envelope.event.payload,
		};
		try {
			await pi.sendUserMessage(JSON.stringify(message), {
				deliverAs: "nextTurn",
				attribution: "agent",
			});
			seen.set(messageIdentity, "api_accepted");
			acknowledge(requestId, "api_accepted", {
				messageId: envelope.messageId,
				modelProcessed: false,
			});
		} catch (error) {
			// The public call may have enqueued before a later runtime error. Never replay it.
			seen.set(messageIdentity, "unknown");
			acknowledge(requestId, "unknown_no_replay", {
				messageId: envelope.messageId,
				reason: error instanceof Error ? error.message : "send failed",
			});
		}
		publishState();
	}

	function connect(ctx: any, reason: "start" | "switch"): void {
		context = ctx;
		if (reason === "switch") {
			generation += 1;
			socket?.end();
			inbound = "";
		}
		ompSessionId = String(ctx.sessionManager.getSessionId());
		connected = false;
		const client = net.createConnection(socketPath);
		socket = client;
		client.on("connect", () => {
			connected = true;
			sendLine(client, {
				kind: "hello",
				protocolVersion: 1,
				token,
				role,
				ompSessionId,
				generation,
				pid: process.pid,
				ompVersion: process.env.WORKBENCH_G3_EXPECTED_OMP_VERSION ?? null,
			});
			publishState();
		});
		client.on("data", chunk => {
			inbound += chunk.toString("utf8");
			for (;;) {
				const index = inbound.indexOf("\n");
				if (index < 0) break;
				const line = inbound.slice(0, index);
				inbound = inbound.slice(index + 1);
				try {
					void handle(JSON.parse(line) as Frame);
				} catch (error) {
					pi.logger?.error?.("workbench G3 extension frame failure", error);
				}
			}
		});
		client.on("error", error => {
			connected = false;
			pi.logger?.error?.("workbench G3 bridge disconnected", error);
		});
		client.on("close", () => {
			connected = false;
		});
	}

	pi.on("session_start", (_event: unknown, ctx: any) => connect(ctx, "start"));
	pi.on("session_switch", (_event: unknown, ctx: any) => {
		connect(ctx, "switch");
	});
	pi.on("session_shutdown", () => socket?.end());
	pi.on("input", () => publishState());
	pi.on("agent_start", () => publishState());
	pi.on("agent_end", () => publishState());
	pi.on("tool_approval_requested", (event: { toolCallId: string; toolName: string }) => {
		approvals.add(event.toolCallId);
		sendEvent("tool_approval_requested", { toolCallId: event.toolCallId, toolName: event.toolName });
		publishState();
	});
	pi.on("tool_approval_resolved", (event: { toolCallId: string; toolName: string; approved: boolean }) => {
		approvals.delete(event.toolCallId);
		sendEvent("tool_approval_resolved", {
			toolCallId: event.toolCallId,
			toolName: event.toolName,
			approved: event.approved,
		});
		publishState();
	});
	pi.on("tool_call", (event: { toolCallId: string; toolName: string }) => {
		const readOnly = READ_ONLY_TOOLS.has(event.toolName);
		if (paused && !readOnly) {
			sendEvent("tool_call_blocked", { toolCallId: event.toolCallId, toolName: event.toolName });
			return { block: true, reason: "Workbench pause: no new mutating tool calls may start." };
		}
		if (!readOnly) mutableCalls.add(event.toolCallId);
		sendEvent("tool_call_allowed", { toolCallId: event.toolCallId, toolName: event.toolName });
		publishState();
		return undefined;
	});
	pi.on("tool_execution_start", (event: { toolCallId: string; toolName: string }) => {
		sendEvent("tool_execution_start", { toolCallId: event.toolCallId, toolName: event.toolName });
		publishState();
	});
	pi.on("tool_execution_end", (event: { toolCallId: string; toolName: string }) => {
		mutableCalls.delete(event.toolCallId);
		sendEvent("tool_execution_end", { toolCallId: event.toolCallId, toolName: event.toolName });
		if (paused && mutableCalls.size === 0) sendEvent("pause_complete");
		publishState();
	});
	pi.on("before_agent_start", () => {
		// The next-turn queue has entered an actual model request. This is not itself
		// proof that the model completed or acted on every queued peer message.
		publishState();
	});
}
