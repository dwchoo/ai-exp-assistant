"""Fail-closed policy primitives for the fixed OMP v18.2.10 G3 probe.

This is a feasibility-gate implementation. Durable delivery state belongs to the
storage port selected by CW-05; this module intentionally keeps only process-local
gate state.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from threading import RLock

from workbench.contracts.v1 import (
    ActorRole,
    ContractError,
    ControlEnvelope,
    MessageEvent,
    MessageKind,
)


class DeliveryState(StrEnum):
    DEFERRED = "deferred"
    DELIVERING = "delivering"
    API_ACCEPTED = "api_accepted"
    UNKNOWN = "unknown"
    REJECTED = "rejected"


class ToolDecision(StrEnum):
    ALLOW = "allow"
    BLOCK_PAUSED = "block_paused"
    READ_ONLY = "read_only"


READ_ONLY_TOOLS = frozenset({"read", "grep", "glob"})
MUTATING_TOOLS = frozenset({"bash", "write", "edit"})


def _message_identity(envelope: ControlEnvelope) -> tuple[str, int, str]:
    return (envelope.session_id, envelope.session_generation, envelope.message_id)


def _valid_direction(envelope: ControlEnvelope, target_role: ActorRole) -> bool:
    if not isinstance(envelope.event, MessageEvent):
        return False
    kind = envelope.event.message_kind
    if target_role is ActorRole.WORKER:
        return envelope.sender_role is ActorRole.MANAGER and kind in {
            MessageKind.TASK,
            MessageKind.QUESTION,
        }
    if target_role is ActorRole.MANAGER:
        return envelope.sender_role is ActorRole.WORKER and kind in {
            MessageKind.ANSWER,
            MessageKind.REPORT,
        }
    return False


@dataclass(slots=True)
class DeliveryLedger:
    """Validates one target session and refuses replay after an uncertain ACK."""

    role: ActorRole
    session_id: str
    generation: int
    _states: dict[tuple[str, int, str], DeliveryState] = field(default_factory=dict)
    _lock: RLock = field(default_factory=RLock, repr=False)

    def begin(
        self,
        encoded_envelope: str | bytes,
        *,
        idle: bool,
        has_pending_messages: bool,
        approval_pending: bool,
        editor_text: str | None,
    ) -> tuple[DeliveryState, ControlEnvelope | None]:
        envelope = ControlEnvelope.from_json(
            encoded_envelope,
            expected_session_id=self.session_id,
            expected_session_generation=self.generation,
        )
        if not _valid_direction(envelope, self.role):
            raise ContractError("message role/kind is not valid for the target OMP role")
        key = _message_identity(envelope)
        with self._lock:
            previous = self._states.get(key)
            if previous is DeliveryState.API_ACCEPTED:
                return DeliveryState.API_ACCEPTED, None
            if previous is DeliveryState.UNKNOWN:
                return DeliveryState.UNKNOWN, None
            if previous is DeliveryState.DELIVERING:
                return DeliveryState.DELIVERING, None
            if (
                not idle
                or has_pending_messages
                or approval_pending
                or editor_text is None
                or editor_text != ""
            ):
                self._states[key] = DeliveryState.DEFERRED
                return DeliveryState.DEFERRED, None
            self._states[key] = DeliveryState.DELIVERING
            return DeliveryState.DELIVERING, envelope

    def finish(self, envelope: ControlEnvelope, *, api_accepted: bool | None) -> DeliveryState:
        key = _message_identity(envelope)
        state = (
            DeliveryState.API_ACCEPTED
            if api_accepted is True
            else DeliveryState.REJECTED
            if api_accepted is False
            else DeliveryState.UNKNOWN
        )
        with self._lock:
            self._states[key] = state
        return state

    def state_for(self, envelope: ControlEnvelope) -> DeliveryState | None:
        with self._lock:
            return self._states.get(_message_identity(envelope))


@dataclass(slots=True)
class ToolPauseGate:
    """Pause future mutating OMP tool calls while allowing one already started to finish."""

    paused: bool = False
    approval_pending: set[str] = field(default_factory=set)
    in_flight_mutations: set[str] = field(default_factory=set)
    _lock: RLock = field(default_factory=RLock, repr=False)

    def tool_call(self, tool_call_id: str, tool_name: str) -> ToolDecision:
        with self._lock:
            if tool_name in READ_ONLY_TOOLS:
                return ToolDecision.READ_ONLY
            is_mutating = tool_name in MUTATING_TOOLS or tool_name not in READ_ONLY_TOOLS
            if self.paused and is_mutating:
                return ToolDecision.BLOCK_PAUSED
            if is_mutating:
                self.in_flight_mutations.add(tool_call_id)
            return ToolDecision.ALLOW

    def approval_requested(self, tool_call_id: str) -> None:
        with self._lock:
            self.approval_pending.add(tool_call_id)

    def approval_resolved(self, tool_call_id: str) -> None:
        with self._lock:
            self.approval_pending.discard(tool_call_id)

    def pause(self) -> bool:
        """Return true when the gate is paused and no previously allowed mutation remains."""
        with self._lock:
            self.paused = True
            return not self.in_flight_mutations

    def tool_finished(self, tool_call_id: str) -> bool:
        with self._lock:
            self.in_flight_mutations.discard(tool_call_id)
            return self.paused and not self.in_flight_mutations

    def may_deliver_message(
        self,
        *,
        idle: bool,
        has_pending_messages: bool,
        editor_text: str | None,
    ) -> bool:
        with self._lock:
            return (
                idle
                and not has_pending_messages
                and not self.approval_pending
                and editor_text == ""
            )


__all__ = [
    "DeliveryLedger",
    "DeliveryState",
    "MUTATING_TOOLS",
    "READ_ONLY_TOOLS",
    "ToolDecision",
    "ToolPauseGate",
]
