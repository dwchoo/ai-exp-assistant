from __future__ import annotations

import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

from workbench.terminal.shell_g2.prototype import (
    ShellChoice,
    ShellProcess,
    ShellUnavailable,
    UnsafeShellState,
    select_shell,
)


def available_shells() -> list[ShellChoice]:
    result: list[ShellChoice] = []
    bash = shutil.which("bash")
    dash = shutil.which("dash")
    if bash:
        result.append(ShellChoice("bash", os.path.realpath(bash)))
    if dash:
        result.append(ShellChoice("sh", os.path.realpath(dash)))
    return result


class ShellSelectionTests(unittest.TestCase):
    def test_bash_is_preferred_and_sh_is_fixed_fallback(self) -> None:
        with tempfile.TemporaryDirectory(prefix="cw03-path-") as path_dir:
            sh = shutil.which("sh")
            self.assertIsNotNone(sh)
            os.symlink(sh, Path(path_dir) / "sh")
            choice = select_shell(path=path_dir)
            self.assertEqual((choice.kind, choice.executable), ("sh", os.path.realpath(sh)))
            with ShellProcess(choice) as session:
                session.wait_ready()
                self.assertEqual(session.choice, choice)
                self.assertTrue(session.boundary.can_dispatch(
                    generation=session.generation,
                    owner_epoch=session.owner_epoch,
                ))

    def test_startup_requirement_when_bash_and_sh_are_absent(self) -> None:
        with tempfile.TemporaryDirectory(prefix="cw03-empty-path-") as empty_path:
            with self.assertRaises(ShellUnavailable):
                select_shell(path=empty_path)


class RealShellGateTests(unittest.TestCase):
    def test_manual_cd_export_and_return_keep_the_same_shell(self) -> None:
        for choice in available_shells():
            with self.subTest(shell=choice.executable), ShellProcess(choice) as session:
                session.wait_ready()
                original_pid = session.pid
                session.take_user_control()
                session.send_user(b"cd /tmp\n")
                session.wait_ready()
                session.send_user(b"export CW03_G2_ENV=kept\n")
                session.wait_ready()

                epoch = session.return_to_manager()
                self.assertTrue(session.boundary.can_dispatch(
                    generation=session.generation,
                    owner_epoch=epoch,
                ))
                self.assertEqual(os.readlink(f"/proc/{original_pid}/cwd"), "/tmp")
                session.dispatch(
                    "same-shell",
                    "__wb_emit STATE:$PWD:$CW03_G2_ENV",
                    expected_epoch=epoch,
                )
                session.wait_command("same-shell")
                self.assertIn("STATE:/tmp:kept", session.events)
                self.assertEqual(session.pid, original_pid)
                self.assertEqual(os.readlink(f"/proc/{original_pid}/cwd"), "/tmp")

    def test_unsubmitted_user_line_and_paste_fail_closed(self) -> None:
        for choice in available_shells():
            with self.subTest(shell=choice.executable), ShellProcess(choice) as session:
                session.wait_ready()
                session.take_user_control()
                session.send_user(b"echo USER_PENDING")
                epoch = session.return_to_manager()
                self.assertFalse(session.boundary.can_dispatch(
                    generation=session.generation,
                    owner_epoch=epoch,
                ))
                with self.assertRaises(UnsafeShellState):
                    session.dispatch(
                        "must-not-submit-user-line",
                        "__wb_emit SHOULD_NOT_RUN",
                        expected_epoch=epoch,
                    )
                self.assertFalse(any("START:must-not-submit-user-line" in item for item in session.events))

        for choice in available_shells():
            with self.subTest(shell=choice.executable, input="paste"), ShellProcess(choice) as session:
                session.wait_ready()
                session.take_user_control()
                session.send_user(b"\x1b[200~echo pasted\n\x1b[201~")
                epoch = session.return_to_manager()
                self.assertFalse(session.boundary.can_dispatch(
                    generation=session.generation,
                    owner_epoch=epoch,
                ))

    def test_real_current_shell_jobs_fd9_reports_background_and_suspend(self) -> None:
        for choice in available_shells():
            with self.subTest(shell=choice.executable, job="background"), ShellProcess(choice) as session:
                session.wait_ready()
                epoch = session.owner_epoch
                session.dispatch("background", "sleep 30 &", expected_epoch=epoch)
                session.wait_command("background")
                self.assertTrue(any(item.startswith("JOBS_BEGIN:background") for item in session.events))
                self.assertTrue(any(item.isdecimal() for item in session.events))
                self.assertTrue(session.boundary.needs_review)
                self.assertFalse(session.boundary.can_dispatch(
                    generation=session.generation,
                    owner_epoch=session.owner_epoch,
                ))

            with self.subTest(shell=choice.executable, job="suspend"), ShellProcess(choice) as session:
                session.wait_ready()
                session.dispatch("suspend", "sleep 30", expected_epoch=session.owner_epoch)
                session.wait_event("START:suspend")
                session.wait_foreground_child()
                session.take_user_control()
                session.send_user(b"\x1a")
                session.wait_command("suspend")
                self.assertTrue(any(item.startswith("JOBS_BEGIN:suspend") for item in session.events))
                self.assertTrue(any(item.isdecimal() for item in session.events))
                self.assertTrue(session.boundary.needs_review)

    def test_failure_repl_interrupt_and_exit_never_become_clean(self) -> None:
        for choice in available_shells():
            with self.subTest(shell=choice.executable, case="failure"), ShellProcess(choice) as session:
                session.wait_ready()
                session.dispatch("failure", "false", expected_epoch=session.owner_epoch)
                session.wait_command("failure")
                self.assertIn("DONE:failure:1", session.events)
                self.assertTrue(session.boundary.needs_review)

            with self.subTest(shell=choice.executable, case="repl"), ShellProcess(choice) as session:
                session.wait_ready()
                session.dispatch("repl", "read -r CW03_VALUE", expected_epoch=session.owner_epoch)
                session.wait_event("START:repl")
                with self.assertRaises(UnsafeShellState):
                    session.dispatch("blocked-behind-repl", ":", expected_epoch=session.owner_epoch)
                time.sleep(0.1)
                self.assertFalse(any(item.startswith("DONE:repl:") for item in session.events))
                session.take_user_control()
                session.send_user(b"\x03")
                with self.assertRaises(TimeoutError):
                    session.wait_command("repl", timeout=0.3)
                self.assertTrue(session.boundary.needs_review)

            with self.subTest(shell=choice.executable, case="exit"), ShellProcess(choice) as session:
                session.wait_ready()
                session.dispatch("exit-shell", "exit 23", expected_epoch=session.owner_epoch)
                session.wait_event("SHELL_EXIT")
                self.assertFalse(any(item.startswith("DONE:exit-shell:") for item in session.events))
                self.assertTrue(session.boundary.needs_review)

    def test_nested_interactive_shell_latches_unknown(self) -> None:
        for choice in available_shells():
            with self.subTest(shell=choice.executable), ShellProcess(choice) as session:
                session.wait_ready()
                session.dispatch(
                    "nested",
                    "bash --noprofile --norc -i" if choice.kind == "bash" else "dash -i",
                    expected_epoch=session.owner_epoch,
                )
                session.wait_event("START:nested")
                session.wait_foreground_child()
                session._detect_nested_shell()
                self.assertTrue(session.boundary.needs_review)
                self.assertFalse(session.boundary.can_dispatch(
                    generation=session.generation,
                    owner_epoch=session.owner_epoch,
                ))


if __name__ == "__main__":
    unittest.main()
