---
name: change-verification
description: "Root-only independent testing, code review and final candidate verification used inside implement. Preserve read-only review requests; never turn review-only into test/code writes."
---

# Change verification — internal procedure

Read `.codex/workflow-contract.md`. Root performs this procedure; leaf agents return results
instead of delegating. Establish mode, approved criteria, verification-unit scope, candidate
and environment. Explicit review-only mode permits inspection/findings only: no tests-as-code,
fixes, integration or implementation dispatch. Do not call implement recursively.

## Independent tests

In authorized implementation mode, transfer the workspace mutation lease only after the
previous writer and subprocesses stop. Dispatch `test_designer` with acceptance IDs,
requirements and test-only write scope. Expected outcomes come from contracts first.
`test_designer` must add/update meaningful tests for new behavior or uncovered regressions; proven
existing coverage can be reused with named evidence. Documentation-only work can justify
no executable test changes. Audit test delta against its baseline.

Classify failures by implementation/test/environment/contract using evidence. For a valid
failing test Root assigns a production fix to `worker`, preserving independent acceptance tests.
For a hard diagnosis Root may consult Oracle under the common budget. Do not let fixes
silently alter the desired behavior or turn failed tests into skipped tests.

## Frozen review

After tests and required production fixes, freeze the actual code+tests candidate. Dispatch
a fresh `reviewer` with SPEC/criteria, complete relevant diff including new files, base,
candidate identity and source context, not a worker's self-evaluation. Read-only reviewers
may inspect separate stable candidates concurrently; no writer mutates the reviewed inputs.

Root adjudicates concrete findings. Route accepted bounded fixes to a writer. If requirements
or accepted design change, pause affected work. Material subsequent deltas need delta/impact
review and rerun affected checks. If impact cannot be bounded, review the unit again. No
endless reviews without new code, evidence or uncovered scope.

## Integration and final evidence

Isolated unit verification is provisional until integrated. Root integrates under exclusive
integration ownership, audits the delta, checks cross-ticket contracts and runs relevant
integration tests. New merge/conflict changes require review coverage. Include final feature
acceptance and required whole-repository checks where the approved verification plan requires.
Record candidate before/after each check, command/cwd/environment/exit code/result/log and
acceptance coverage. Stale or missing evidence cannot become a final pass by relabeling.
Return evidence and gaps; Root declares the contract's final status. No remote publication.

## What the evidence establishes

`test_designer` should exercise the agreed public behavior with contract-derived expected outcomes,
including a relevant failure or regression. Avoid assertions that recompute the same
implementation or replace the behavior under test with a mock. Use controlled doubles at
external or nondeterministic boundaries and state which integration remains untested.
Reuse the approved test seams without requesting approval again for routine test work.

Label parser and file checks as static, controlled helper executions as fixture tests,
model responses and tool actions as skill behavior evidence, and actual host sessions as
runtime evidence. A result at one level does not establish a result at the next level.
Keep independent testing and frozen review even when a newer prompting guide recommends
less repetitive checking; scale the checks to the change without weakening acceptance.
