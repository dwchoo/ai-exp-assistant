# Dispatch / Oracle evidence packet

These are proposed handoff fields, not Codex tool arguments. Supply them using the installed
host's actual supported messaging/cwd mechanisms. Do not invent spawn parameters.

## Assignment
- feature_id, ticket_id, attempt_id, approved_bundle_digest
- actual_workspace, repository_identity, baseline_snapshot, effective_write_capability
- acceptance_ids, relevant_contracts, allowed_write_paths, prohibited_paths
- generated_outputs, resource_claims, mutation_owner, checkpoint_ref
- exact_checks, reserved_budget, stop_conditions

## Result
- ticket_id, status: candidate_ready / needs_oracle / blocked
- actual_workspace, base_snapshot, candidate_id, attributable_output_bundle
- changed_paths, scope_audit, checks with command/cwd/exit_code/result/evidence
- active_or_stopped_subprocesses, remaining_gaps

## Oracle request (always routed by Root)
- incident_id, ticket_id, spec_revision, candidate_id
- expected_behavior, observed_behavior
- reproducer_and_logs (or explicit missing-evidence statement)
- attempted_approaches and observable outcomes
- constraints, unknowns, precise_question

## Oracle response
- supported_observations, candidate_hypotheses, uncertainty
- discriminating_experiments, minimal_fix_direction
- regression_test_ideas, integration_risks, plan_invalidated, remaining_unknowns

Oracle does not mutate the code/state or mark an incident resolved. Root authorizes and
runs/dispatches experiments and fixes, then verifies them independently.
