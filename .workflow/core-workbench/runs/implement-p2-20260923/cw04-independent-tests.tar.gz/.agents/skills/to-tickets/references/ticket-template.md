# <T-ID>: <title>

Specification: <path/revision>. Scheduling: ../PLAN.json entry <T-ID>.
Status and live assignments are maintained only by Root in the operational state record.

## Delivered behavior
## Acceptance criteria
Reference SPEC IDs and give ticket-specific observable outcomes.
## Contracts and relevant context
Stable interfaces and evidence, including prerequisite deliverables.
## Verification
Worker checks; independent `test_designer` assessment/tests; fresh `reviewer` review; integration checks.
## Out of scope and stop conditions
## Output handoff
Candidate/output bundle, attributable paths, exact check evidence, gaps/needs_oracle.
