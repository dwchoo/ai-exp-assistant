# Repository workflow contract — v4

Repository policy, NOT a Codex API/schema or executable scheduler. Read this document
explicitly from the workflow skills. It never overrides system/developer instructions,
user authorization, managed permissions, or stronger repository rules.

## 1. Three phases and four public entry points

- `refine-spec`: user-selected Astra session; interview and document agreed intent.
- `to-tickets`: fresh user-selected Sol XHigh/Max session; compile the persisted brief
  into an implementation specification plus dependency-aware tickets in one invocation.
- `implement`: Sol-owned development; dispatch ready tickets, integrate, independently
  test and review, repair and run final checks. GPT-6 Sol XHigh is the project default;
  an explicitly chosen supported higher effort is not automatically lowered.
- `ask-workflow`: inspect current evidence and recommend the next step; do not execute it.
- `change-verification`: internal Root procedure, also usable for explicit verification.

Skills do not select/switch the active model. Accept the user's stated model selection;
inspect authoritative host metadata when available. Label unavailable metadata unverified,
not a fabricated mismatch. Never claim a model switch from prompt text or self-report.
Actual known mismatches/capability limitations must be surfaced.

Only the active top-level owner delegates, integrates, updates shared workflow state and
spends the parent budget. All custom agents are leaves: no recursive spawning, no lifecycle
skill re-entry, no hidden CLI/SDK agent processes. A worker requests Oracle help through
Root; Root calls an Oracle sibling and relays the evidence-backed answer. Domain skills
within assigned scope remain allowed. Root may consult Oracle during planning or development
for a specific hard technical question; Oracle is not a mandatory planning stage.

## 2. Persistent handoff, not shared conversation memory

Honor existing repository documentation layout. Defaults:
- `CONTEXT.md`: domain glossary only; use `CONTEXT-MAP.md` if the project already has contexts.
- `docs/adr/`: accepted hard-to-reverse, non-obvious trade-off decisions, created sparingly.
- `docs/features/<feature>/BRIEF.md`: approved intent, constraints, decisions, evidence,
  acceptance examples, non-goals, open/deferred questions and revision.
- `docs/features/<feature>/SPEC.md`: executable behavior, interfaces, invariants,
  failure semantics and verification requirements derived from that brief.
- `docs/features/<feature>/PLAN.json`: canonical ticket graph and scheduling constraints.
- `docs/features/<feature>/tickets/<id>.md`: one self-contained narrative per ticket.
- `.workflow/<feature>/state.json` and `runs/<run-id>/`: Root-owned operational records,
  in an authorized writable location. Relocate if repository policy requires it.

Create artifacts lazily. Do not put implementation plans into the glossary. Do not use
ADRs as a replacement for the brief. New sessions must read the full relevant brief,
glossary, ADRs and source references; absence from current chat is not absence of evidence.
Distinguish user decisions, observed facts, recommendations, assumptions, and unresolved items.
Do not publish issues, alter global configs, create PRs, commit/push, deploy, or migrate
production merely because a source skill recommends doing so.

## 3. Approval, revision and source of truth

A file saying approved is not authorization by itself. Record a user approval reference
and tool-computed manifest/digest in a separate state/run record. The approved bundle covers
BRIEF, SPEC, PLAN and ticket contents as relevant; hashes do not include their own record.
Approval of a brief authorizes downstream planning, not product implementation. An explicit
request to implement an unambiguous presented plan may approve it and authorize execution
in one message. Do not ask again at each worker/test/review boundary.

Sol may elaborate technical details inside approved constraints. It must not silently
change user-facing behavior, scope, acceptance, compatibility promises or accepted ADRs.
Missing material decisions produce concrete blockers or a focused decision request, not a
second general interview. A prototype/research question can be recorded as deferred;
unresolved prerequisites block affected tickets rather than being invented away.

PLAN.json is canonical for dependencies, resource claims, ticket IDs and scheduling fields;
ticket Markdown holds intent and criteria, referencing that plan without independently
maintained status/graph copies. The state file is an operational index, not proof. Verify
its revisions, candidates and evidence against the actual repository and host on resume.
Changed inputs make dependent evidence stale. Preserve completed/unaffected work when
regenerating a plan; retain stable IDs and record superseded tickets instead of silently
renumbering active work. A changed approved bundle needs scope-appropriate authorization.

## 4. Logical dependencies versus execution conflicts

Use dependency edges only for real prerequisite deliverables. Prefer verifiable vertical
slices; shared interfaces can be a bounded prerequisite. A wide refactor may use an approved
expand/migrate/contract sequence instead. Do not manufacture parallelism by claiming a
consumer is independent of an unsettled API. Contract-first parallelism must state the
shared interface, contract tests and subsequent integration verification.

Separately record write ownership and mutable-resource constraints: generated files,
lockfiles, ports, database/schema, caches, service instances and credentials where relevant.
A resource claim has a canonical resource name and mode `shared` or `exclusive`.
Two live claims conflict if names match and either is exclusive. Shared mode is valid
only for genuinely concurrent-safe access; read-only code may still invoke mutating tools.
File overlap or semantic conflict may require serialization despite separate worktrees.

A runnable ticket needs: authorized current plan; dependencies integrated and sufficiently
validated at the approved integration boundary; a current base snapshot; an available
worker slot; confirmed writable workspace and permissions; a free mutation lease and
compatible resource claims; a recoverable checkpoint; and reserved verification budget.
`parallelizable: true` alone is never sufficient. Recompute readiness after every event;
do not wait for an unrelated slow ticket to finish a whole artificial wave.

## 5. Workspaces and mutation leases

Default to one mutation owner per physical worktree/workspace, NOT one writer globally.
Count Root, workers, test authors, formatters, generators and other mutating subprocesses.
Concurrent writers require distinct verified worktrees/isolated workspaces plus safe
shared-resource access. A new agent thread or different branch name alone is not isolation.
A worktree is filesystem-change isolation, not a security sandbox or database isolation.

Before dispatch, Root provisions or identifies an authorized workspace and verifies actual
cwd/repository identity, current base, writable roots, necessary config/skills, dependencies,
logs and service namespace. Do not invent a spawn `cwd` parameter. Use only capabilities
actually exposed by the installed host. Merely telling an agent a path is an instruction,
not an OS-level boundary. If isolation cannot be established, execute serially and report
the limitation; do not silently start multiple writers in the shared checkout.

A Git checkout at HEAD does not automatically contain dirty/untracked input. Preserve and
transfer the exact approved input snapshot through an authorized mechanism. Never commit,
stash, reset or clean user changes just to create a baseline. Worktree provisioning and Git
metadata writes may require additional approval; do not bypass it. Use a manifest-backed
patch/output bundle when commits are not authorized. Do not leave essential configuration
behind when workspaces are created before uncommitted configuration is installed.

A blocked worker must finish/stop mutating processes and report its partial delta before
its lease transfers. Do not hold a worker thread indefinitely just to await Oracle if that
starves capacity. Root alone integrates one attributable verified delta at a time into the
integration workspace. Merge conflicts are new work, not permission to choose a side blindly.
Rebase/merge/patch adaptation changes the candidate and invalidates affected check/review
coverage. Reassess remaining ticket assumptions after each integration.

## 6. Checkpoints, scope audits and evidence

Capture enough bytes/provenance to preserve staged, unstaged and untracked pre-existing
user work before each writer. A digest is not a backup. Audit actual changes against the
assignment baseline, not only HEAD: additions, removals, renames, modes, symlinks, relevant
ignored/generated inputs and submodule state. Resolve path boundaries. Scope restrictions
in a prompt are detective unless enforced by effective permissions.

On out-of-scope writes: stop dependent integration, retain evidence, isolate/remove only
the attributable agent delta without harming user work, audit and rerun affected checks.
If safe attribution/recovery is impossible, leave files intact and report blocked. No
blanket reset/clean/restore. Workers never directly edit the central plan/state/approvals.

A candidate ID resolves to a tool-observed immutable snapshot/manifest of validation inputs,
including relevant tests, fixtures, config, locks, new and dirty files, modes and submodules.
Record toolchain/service environment separately. Exclude only true operational logs/state,
not test inputs. Check input identity before and after a frozen review/check. Changes during
execution make the result stale. A bare commit SHA cannot identify an arbitrary dirty tree.

Each check records command, cwd, candidate, environment, exit code when executed, criteria,
result (`passed`, `failed`, `not_run`) and evidence. Empty collection is not useful pass proof.
Final coverage comprises the relevant original reviews plus bounded delta reviews; if impact
is uncertain, review the whole unit again. Do not relabel an older result as a final pass.

## 7. Mandatory tests, review and integration

`implement` includes independent `test_designer` test assessment/code and fresh `reviewer` review for
each coherent verification unit, followed by feature integration verification. Group small
tickets where justified, but make a dependency gate explicit. Worker TDD does not replace
`test_designer`; passing tests do not replace reviewer analysis. Reviewer is not Root self-review.

`test_designer` derives expected outcomes from approved behavior before inspecting implementation.
Add meaningful tests for new behavior/uncovered regressions; reuse proven existing coverage
with named evidence. Documentation-only work can justify no executable test addition.
Do not weaken acceptance tests to fit an implementation. Test failure may arise from code,
test, environment or contract; classify it using evidence. A known bug need not have a
perfect reproducer before Oracle can help design a discriminating experiment.

Within each workspace/unit: implement and quick checks -> independent tests -> necessary
production fix -> frozen code+tests review -> bounded corrections and delta review -> checks.
Different units may pipeline concurrently in separate verified workspaces. Never review a
moving target simply because the reviewer itself is read-only. Final integration gets
cross-ticket tests and review coverage of integration deltas before required final checks.
Every approved acceptance ID must map to implementation and current verification evidence.

## 8. Oracle and finite recovery budgets

`oracle` (High) and `deep_oracle` (Max) are two configured variants of one
read-only advisory role. No Astra Max planner, automatic pre-implementation Oracle pass,
self-dispatch, product modifications or final approval powers. Root owns decisions.

Call for a specific hard root cause, conflicting observations, repeated bounded failure,
cross-module invariant or design contradiction. Do not call for a routine typo, missing
install/permission, or unknown file location that a focused lookup can resolve. Worker,
tester or reviewer may request advice, but Root selects and invokes the sibling Oracle.
High is the default; Max can be selected directly for a documented deep question or once
as escalation. Do not require a wasted High call first. Repeated calls need new evidence or
a genuinely unresolved question. Stronger model output is still a hypothesis until checked.

Consultation input: ticket/incident ID, spec and candidate, constraints, expected/observed
behavior, logs/reproducer if available, attempts and outcomes, known/unknown facts, precise
question. Output: supported observations, hypotheses with discriminating experiments,
smallest fix direction, risks, regression-test ideas, whether an approved decision is
invalidated, and what remains unknown. Root/worker executes mutating experiments/fixes.
Oracle advice never closes a ticket, waives verification or changes acceptance criteria.

Declare finite feature/run budgets before dispatch, including test, reviewer and fix capacity.
Pilot defaults: 4 open child threads, 2 parallel writer workspaces, 1 global integration owner,
2 worker attempts per unresolved issue, 2 Oracle calls per incident, 4 Oracle calls per run,
2 corrective review cycles per verification unit, and total child-run budget sized by the
approved ticket/unit count. These are proposed policies, not product defaults or billing caps.
No new run/incident/ticket resets a continuing unresolved problem's budget without recorded
authorization. Incident detection and resource locks are procedural unless a host enforces them.
When blocked, continue unaffected ready work only within original scope and remaining budget.

## 9. Status and resumption

Suggested phase: discovery / planning / ready / implementing / verifying / blocked / complete.
Ticket states: pending -> ready -> running -> candidate_ready -> verifying -> integrated;
blocked and stale are explicit alternatives. Worker 'done' does not satisfy an integration edge.
Final result:
- done_verified: current approved scope, tests, independent review, scope audit and required
  final checks all satisfied on the delivered integrated candidate; no material unresolved issue.
- implemented_unverified: implementation exists but necessary evidence is missing; do not
  hide an observed required failure here.
- blocked: known required failure, contract/scope/permission/capability/recovery or budget blocker.

On interruption record active assignments, candidates, partial deltas and evidence, then stop.
No promise of future/background execution. On resume inspect the host and processes; do not
assume recorded leases are free or recorded workers remain active. Do not launch duplicate
workers for a ticket with unknown execution state. `ask-workflow` reports uncertainty and
one next step; it never writes state, releases leases, invokes Oracle, or resumes work itself.

## 10. Limits

This bundle is instruction/configuration scaffolding, not a tested worktree provisioner,
lock service, durable job runner, sandbox profile or CI gate. Static parsing cannot prove
runtime model selection, root-only delegation, permissions, actual parallel execution or
workflow compliance. Test those with the supplied smoke cases on the installed Codex build.
