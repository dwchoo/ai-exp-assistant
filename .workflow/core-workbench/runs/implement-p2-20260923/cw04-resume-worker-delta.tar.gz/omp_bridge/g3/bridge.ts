import net from "node:net";
import { parseControlEnvelope } from "../contract/v1.ts";

type Role = "manager" | "worker";
type Frame = Record<string, unknown>;

const READ_ONLY_TOOLS = new Set(["read", "grep", "glob"]);

function env(name: string): string {
	const value = process.env[name];
	if (!value) throw new Error(`missing ${name}`);
	return value;
}

function sendLine(socket: net.Socket, value: Frame): void {
	if (!socket.destroyed) socket.write(`${JSON.stringify(value)}\n`);
}

function roleAllows(role: Role, senderRole: string, kind: string): boolean {
	return role === "worker"
		? senderRole === "manager" && (kind === "task" || kind === "question")
		: senderRole === "worker" && (kind === "answer" || kind === "report");
}

export default function workbenchG3Extension(pi: any): void {
	const socketPath = env("WORKBENCH_G3_BRIDGE_SOCKET");
	const role = env("WORKBENCH_G3_ROLE") as Role;
	const token = env("WORKBENCH_G3_TOKEN");
	const expectedResponseMarker = process.env.WORKBENCH_G3_EXPECTED_RESPONSE_MARKER;
	let generation = Number(env("WORKBENCH_G3_GENERATION"));
	if ((role !== "manager" && role !== "worker") || !Number.isSafeInteger(generation) || generation < 1) {
		throw new Error("invalid G3 role or session generation");
	}

	let socket: net.Socket | undefined;
	let context: any;
	let ompSessionId = "";
	let paused = false;
	let connected = false;
	let inbound = "";
	let shuttingDown = false;
	let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
	let reconnectAttempt = 0;
	const seen = new Map<string, "sending" | "api_accepted" | "unknown">();
	const approvals = new Set<string>();
	const mutableCalls = new Set<string>();
	let previousWrite: Promise<void> = Promise.resolve();

	pi.registerTool({
		name: "write",
		label: "Write",
		description: "Write a file",
		parameters: pi.zod.object({ path: pi.zod.string(), content: pi.zod.string() }),
		// Native write can require exec approval for some targets. A static extension tier
		// must not grant less than the native tool can require.
		approval: "exec",
		strict: true,
		loadMode: "essential",
		async execute(_id: string, params: { path: string; content: string }, signal: AbortSignal, onUpdate: any, ctx: any) {
			const before = previousWrite;
			let release!: () => void;
			previousWrite = new Promise<void>(resolve => { release = resolve; });
			await before;
			try {
				if (paused || signal?.aborted || typeof ctx.invokeTool !== "function") {
					return {
						content: [{ type: "text", text: "Workbench pause or unavailable native write blocked mutation." }],
						isError: true,
					};
				}
				return await ctx.invokeTool(params, { signal, onUpdate });
			} finally {
				release();
			}
		},
	});

	function snapshot(): Frame {
		let editorText: string | undefined;
		try {
			editorText = context?.ui?.getEditorText?.();
		} catch {
			editorText = undefined;
		}
		let idle = false;
		let pending = true;
		try {
			idle = context?.isIdle?.() === true;
			pending = context?.hasPendingMessages?.() !== false;
		} catch {
			// Unknown state remains fail-closed.
		}
		return {
			kind: "state",
			role,
			sessionId: ompSessionId,
			generation,
			idle,
			pending,
			approvalPending: approvals.size > 0,
			inFlightMutationCount: mutableCalls.size,
			editorKnown: typeof editorText === "string",
			editorEmpty: editorText === "",
			editorLength: typeof editorText === "string" ? editorText.length : null,
			paused,
		};
	}

	function publishState(): void {
		if (connected) sendLine(socket!, snapshot());
	}

	function isCurrentConnection(client: net.Socket, sessionId: string, sessionGeneration: number): boolean {
		return !shuttingDown
			&& socket === client
			&& ompSessionId === sessionId
			&& generation === sessionGeneration;
	}

	function acknowledge(
		client: net.Socket,
		sessionId: string,
		sessionGeneration: number,
		requestId: string,
		status: string,
		extra: Frame = {},
	): void {
		if (isCurrentConnection(client, sessionId, sessionGeneration)) {
			sendLine(client, { kind: "api_ack", requestId, status, ...extra });
		}
	}

	function sendEvent(name: string, fields: Frame = {}): void {
		if (!connected) return;
		sendLine(socket!, { kind: "omp_event", name, sessionId: ompSessionId, generation, ...fields });
	}

	function isMessageSafe(): boolean {
		const state = snapshot();
		return state.idle === true
			&& state.pending === false
			&& state.approvalPending === false
			&& state.editorKnown === true
			&& state.editorEmpty === true
			&& mutableCalls.size === 0;
	}

	async function handle(
		frame: Frame,
		client: net.Socket,
		sessionId: string,
		sessionGeneration: number,
	): Promise<void> {
		if (!isCurrentConnection(client, sessionId, sessionGeneration)) return;
		const ack = (requestId: string, status: string, extra: Frame = {}) =>
			acknowledge(client, sessionId, sessionGeneration, requestId, status, extra);
		if (frame.kind === "probe" && typeof frame.requestId === "string") {
			ack(frame.requestId, "state", { state: snapshot() });
			return;
		}
		if (frame.kind === "pause" && typeof frame.requestId === "string") {
			paused = true;
			const complete = mutableCalls.size === 0;
			ack(frame.requestId, complete ? "paused" : "pause_waiting", {
				inFlightMutationCount: mutableCalls.size,
				approvalPendingCount: approvals.size,
			});
			publishState();
			return;
		}
		if (frame.kind !== "deliver" || typeof frame.requestId !== "string" || typeof frame.envelope !== "string") return;

		const requestId = frame.requestId;
		let envelope: ReturnType<typeof parseControlEnvelope>;
		try {
			envelope = parseControlEnvelope(JSON.parse(frame.envelope) as unknown, {
				sessionId: ompSessionId,
				sessionGeneration: generation,
			});
		} catch (error) {
			ack(requestId, "rejected", { reason: error instanceof Error ? error.message : "invalid envelope" });
			return;
		}
		if (envelope.event.type !== "message" || !roleAllows(role, envelope.senderRole, envelope.event.messageKind)) {
			ack(requestId, "rejected", { reason: "role/kind does not match target OMP session" });
			return;
		}
		const messageIdentity = `${envelope.sessionId}:${envelope.sessionGeneration}:${envelope.messageId}`;
		const prior = seen.get(messageIdentity);
		if (prior === "api_accepted") {
			ack(requestId, "duplicate_api_accepted", { messageId: envelope.messageId });
			return;
		}
		if (prior === "unknown" || prior === "sending") {
			ack(requestId, "unknown_no_replay", { messageId: envelope.messageId });
			return;
		}
		if (!isMessageSafe()) {
			ack(requestId, "deferred", { reason: "OMP is busy, has pending work/approval, or composer state is unsafe" });
			publishState();
			return;
		}

		seen.set(messageIdentity, "sending");
		const message = {
			workbench_message_id: envelope.messageId,
			workbench_delivery_attempt_id: envelope.deliveryAttemptId,
			kind: envelope.event.messageKind,
			...(envelope.event.inReplyToMessageId === undefined
				? {} : { in_reply_to_message_id: envelope.event.inReplyToMessageId }),
			task_id: envelope.taskId,
			revision_id: envelope.revisionId,
			run_id: envelope.runId,
			payload: envelope.event.payload,
		};
		try {
			await pi.sendUserMessage(JSON.stringify(message), {
				attribution: "agent",
			});
			seen.set(messageIdentity, "api_accepted");
			ack(requestId, "api_accepted", {
				messageId: envelope.messageId,
				modelProcessed: false,
			});
		} catch (error) {
			// The public call may have enqueued before a later runtime error. Never replay it.
			seen.set(messageIdentity, "unknown");
			ack(requestId, "unknown_no_replay", {
				messageId: envelope.messageId,
				reason: error instanceof Error ? error.message : "send failed",
			});
		}
		if (isCurrentConnection(client, sessionId, sessionGeneration)) publishState();
	}

	function clearReconnect(): void {
		if (reconnectTimer !== undefined) clearTimeout(reconnectTimer);
		reconnectTimer = undefined;
	}

	function openConnection(): void {
		if (shuttingDown) return;
		inbound = "";
		connected = false;
		const client = net.createConnection(socketPath);
		const sessionId = ompSessionId;
		const sessionGeneration = generation;
		socket = client;
		client.on("connect", () => {
			if (!isCurrentConnection(client, sessionId, sessionGeneration)) {
				client.end();
				return;
			}
			connected = true;
			reconnectAttempt = 0;
			sendLine(client, {
				kind: "hello",
				protocolVersion: 1,
				token,
				role,
				ompSessionId,
				generation,
				pid: process.pid,
				ompVersion: process.env.WORKBENCH_G3_EXPECTED_OMP_VERSION ?? null,
			});
			publishState();
		});
		client.on("data", chunk => {
			if (!isCurrentConnection(client, sessionId, sessionGeneration)) return;
			inbound += chunk.toString("utf8");
			for (;;) {
				const index = inbound.indexOf("\n");
				if (index < 0) break;
				const line = inbound.slice(0, index);
				inbound = inbound.slice(index + 1);
				try {
					void handle(JSON.parse(line) as Frame, client, sessionId, sessionGeneration)
						.catch(error => pi.logger?.error?.("workbench G3 bridge frame handler failure", error));
				} catch (error) {
					pi.logger?.error?.("workbench G3 extension frame failure", error);
				}
			}
		});
		client.on("error", error => {
			if (isCurrentConnection(client, sessionId, sessionGeneration)) {
				connected = false;
				pi.logger?.error?.("workbench G3 bridge disconnected", error);
			}
		});
		client.on("close", () => {
			if (!isCurrentConnection(client, sessionId, sessionGeneration)) return;
			connected = false;
			if (shuttingDown || reconnectTimer !== undefined) return;
			const delayMs = Math.min(50 * (2 ** Math.min(reconnectAttempt, 5)), 1000);
			reconnectAttempt += 1;
			reconnectTimer = setTimeout(() => {
				reconnectTimer = undefined;
				if (isCurrentConnection(client, sessionId, sessionGeneration)) openConnection();
			}, delayMs);
			reconnectTimer.unref?.();
		});
	}

	function connect(ctx: any, reason: "start" | "switch"): void {
		if (shuttingDown) return;
		context = ctx;
		if (reason === "switch") generation += 1;
		ompSessionId = String(ctx.sessionManager.getSessionId());
		clearReconnect();
		reconnectAttempt = 0;
		const previous = socket;
		socket = undefined;
		connected = false;
		inbound = "";
		previous?.end();
		openConnection();
	}

	pi.on("session_start", (_event: unknown, ctx: any) => connect(ctx, "start"));
	pi.on("session_switch", (_event: unknown, ctx: any) => {
		connect(ctx, "switch");
	});
	pi.on("session_shutdown", () => {
		shuttingDown = true;
		clearReconnect();
		const previous = socket;
		socket = undefined;
		connected = false;
		inbound = "";
		previous?.end();
	});
	pi.on("input", () => publishState());
	pi.on("agent_start", () => {
		sendEvent("agent_start");
		publishState();
	});
	pi.on("agent_end", () => {
		sendEvent("agent_end");
		publishState();
	});
	pi.on("before_provider_request", () => sendEvent("provider_request_started"));
	pi.on("after_provider_response", () => sendEvent("provider_response_received"));
	pi.on("message_end", (event: { message?: { role?: string; content?: unknown } }) => {
		if (!expectedResponseMarker || event?.message?.role !== "assistant") return;
		const content = event.message.content;
		const text = Array.isArray(content)
			? content
				.filter((block): block is { type: string; text: string } =>
					typeof block === "object"
						&& block !== null
						&& "type" in block
						&& block.type === "text"
						&& "text" in block
						&& typeof block.text === "string")
				.map(block => block.text)
				.join("")
			: "";
		// Report only whether the one-time probe sentinel appeared. Never forward model text.
		sendEvent("assistant_message_end", { responseMarkerMatched: text.includes(expectedResponseMarker) });
		publishState();
	});
	pi.on("tool_approval_requested", (event: { toolCallId: string; toolName: string }) => {
		approvals.add(event.toolCallId);
		sendEvent("tool_approval_requested", { toolCallId: event.toolCallId, toolName: event.toolName });
		publishState();
	});
	pi.on("tool_approval_resolved", (event: { toolCallId: string; toolName: string; approved: boolean }) => {
		approvals.delete(event.toolCallId);
		sendEvent("tool_approval_resolved", {
			toolCallId: event.toolCallId,
			toolName: event.toolName,
			approved: event.approved,
		});
		publishState();
	});
	pi.on("tool_call", (event: { toolCallId: string; toolName: string }) => {
		const readOnly = READ_ONLY_TOOLS.has(event.toolName);
		if (paused && !readOnly) {
			sendEvent("tool_call_blocked", { toolCallId: event.toolCallId, toolName: event.toolName });
			return { block: true, reason: "Workbench pause: no new mutating tool calls may start." };
		}
		if (!readOnly) mutableCalls.add(event.toolCallId);
		sendEvent("tool_call_allowed", { toolCallId: event.toolCallId, toolName: event.toolName });
		publishState();
		return undefined;
	});
	pi.on("tool_execution_start", (event: { toolCallId: string; toolName: string }) => {
		sendEvent("tool_execution_start", { toolCallId: event.toolCallId, toolName: event.toolName });
		publishState();
	});
	pi.on("tool_execution_end", (event: { toolCallId: string; toolName: string }) => {
		mutableCalls.delete(event.toolCallId);
		sendEvent("tool_execution_end", { toolCallId: event.toolCallId, toolName: event.toolName });
		if (paused && mutableCalls.size === 0) sendEvent("pause_complete");
		publishState();
	});
	pi.on("before_agent_start", () => {
		// A prompt is being prepared for the provider; completion is observed separately.
		publishState();
	});
}
