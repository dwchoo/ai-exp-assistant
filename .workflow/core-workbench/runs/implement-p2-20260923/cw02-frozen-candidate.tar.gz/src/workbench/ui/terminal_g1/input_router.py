"""Raw-byte host input router; only its documented UI keys are consumed."""
from __future__ import annotations

import time


class InputRouter:
    _paste_start = b"\x1b[200~"
    _paste_end = b"\x1b[201~"
    _keys = {
        b"\x1b[17~": "focus_next",  # xterm F6
        b"\x1b[18~": "scroll_up",  # xterm F7
        b"\x1b[19~": "scroll_down",  # xterm F8
        b"\x1b[21~": "quit",  # xterm F10
    }

    def __init__(self) -> None:
        self._pending = bytearray()
        self._pending_since = 0.0
        self._in_bracketed_paste = False

    def feed(self, data: bytes, *, now: float | None = None) -> list[bytes | str]:
        if data:
            if not self._pending:
                self._pending_since = time.monotonic() if now is None else now
            self._pending.extend(data)
        events: list[bytes | str] = []
        passthrough = bytearray()
        current_time = time.monotonic() if now is None else now

        def flush_passthrough() -> None:
            if passthrough:
                events.append(bytes(passthrough))
                passthrough.clear()

        while self._pending:
            if self._in_bracketed_paste:
                end_index = self._pending.find(self._paste_end)
                if end_index >= 0:
                    end = end_index + len(self._paste_end)
                    passthrough.extend(self._pending[:end])
                    del self._pending[:end]
                    self._in_bracketed_paste = False
                    self._pending_since = current_time
                    continue

                # Keep a possible split paste-end marker until the next read.
                safe_length = max(0, len(self._pending) - len(self._paste_end) + 1)
                if safe_length:
                    passthrough.extend(self._pending[:safe_length])
                    del self._pending[:safe_length]
                    self._pending_since = current_time
                elif current_time - self._pending_since >= 0.06:
                    passthrough.extend(self._pending)
                    self._pending.clear()
                    self._pending_since = current_time
                break

            if self._pending.startswith(self._paste_start):
                flush_passthrough()
                passthrough.extend(self._paste_start)
                del self._pending[: len(self._paste_start)]
                self._in_bracketed_paste = True
                self._pending_since = current_time
                continue

            for sequence, action in self._keys.items():
                if self._pending.startswith(sequence):
                    flush_passthrough()
                    del self._pending[: len(sequence)]
                    events.append(action)
                    self._pending_since = current_time
                    break
            else:
                pending_bytes = bytes(self._pending)
                if any(
                    key.startswith(pending_bytes)
                    for key in (*self._keys, self._paste_start)
                ):
                    if current_time - self._pending_since < 0.06:
                        break
                passthrough.extend(self._pending[:1])
                del self._pending[:1]
                self._pending_since = current_time
        flush_passthrough()
        return events

    def flush(self, *, now: float | None = None) -> list[bytes | str]:
        return self.feed(b"", now=now)
