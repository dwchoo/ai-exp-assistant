from __future__ import annotations

import os
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

from workbench.terminal.vt_g1.screen import TerminalScreen, make_stream
from workbench.terminal.vt_g1.session import PtySession
from workbench.ui.terminal_g1.input_router import InputRouter


class TerminalScreenTests(unittest.TestCase):
    def test_wide_korean_glyph_uses_two_cells_without_losing_next_character(self) -> None:
        screen = TerminalScreen(8, 2)
        make_stream(screen).feed("가X".encode("utf-8"))

        self.assertEqual(screen.buffer[0][0].data, "가")
        self.assertEqual(screen.buffer[0][1].data, "")
        self.assertEqual(screen.buffer[0][2].data, "X")
        self.assertEqual(screen.cursor.x, 3)

    def test_unicode_truecolor_alt_screen_and_restore(self) -> None:
        screen = TerminalScreen(20, 5)
        stream = make_stream(screen)
        stream.feed("main 가".encode())
        stream.feed(b"\x1b[38;2;107;114;128mC")

        self.assertEqual("".join(screen.buffer[0][x].data for x in range(7)), "main 가")
        self.assertEqual(screen.buffer[0][7].fg, "6b7280")
        stream.feed(b"\x1b[?1049hALT")
        self.assertTrue(screen._terminal_control["using_alternate"])
        self.assertEqual("".join(screen.buffer[0][x].data for x in range(3)), "ALT")
        stream.feed(b"\x1b[?1049l")
        self.assertFalse(screen._terminal_control["using_alternate"])
        self.assertEqual(screen.buffer[0][0].data, "m")

    def test_device_status_cursor_and_device_attribute_replies(self) -> None:
        replies: list[bytes] = []
        screen = TerminalScreen(20, 5, reply=replies.append)
        stream = make_stream(screen)
        stream.feed(b"X\x1b[6n\x1b[c\x1b[5n")

        self.assertEqual(replies, [b"\x1b[1;2R", b"\x1b[?6c", b"\x1b[0n"])

    def test_resize_in_alternate_screen_restores_primary_at_new_size(self) -> None:
        screen = TerminalScreen(8, 2)
        stream = make_stream(screen)
        stream.feed(b"MAIN\x1b[?1049hALT")
        screen.resize(lines=4, columns=12)
        stream.feed(b"\x1b[?1049l")

        self.assertEqual((screen.columns, screen.lines), (12, 4))
        self.assertEqual("".join(screen.buffer[0][x].data for x in range(4)), "MAIN")

    def test_scrollback_can_page_and_restore(self) -> None:
        screen = TerminalScreen(8, 2, history=20)
        stream = make_stream(screen)
        stream.feed(b"one\r\ntwo\r\nthree\r\nfour\r\n")
        bottom = "".join(screen.buffer[0][x].data for x in range(3))
        screen.prev_page()
        prior = "".join(screen.buffer[0][x].data for x in range(3))
        screen.next_page()
        restored = "".join(screen.buffer[0][x].data for x in range(3))

        self.assertNotEqual(prior, bottom)
        self.assertEqual(restored, bottom)


class PtyAndInputTests(unittest.TestCase):
    def test_real_pty_query_reply_uses_child_input_not_display_text(self) -> None:
        script = (
            "import os, select, tty\n"
            "tty.setraw(0)\n"
            "os.write(1, b'\\x1b[6n')\n"
            "if not select.select([0], [], [], 2)[0]: raise SystemExit(3)\n"
            "reply = os.read(0, 64)\n"
            "os.write(1, b'REPLY:' + reply.hex().encode() + b'\\n')\n"
        )
        session = PtySession([sys.executable, "-c", script])
        screen = TerminalScreen(20, 5, reply=session.write)
        stream = make_stream(screen)
        output = bytearray()
        try:
            deadline = time.monotonic() + 3
            while time.monotonic() < deadline and session.poll() is None:
                data = session.read_available()
                output.extend(data)
                stream.feed(data)
                time.sleep(0.01)
            output.extend(session.read_available())
            self.assertEqual(session.poll(), 0)
            self.assertIn(b"REPLY:1b5b313b3152", output)
        finally:
            session.close()

    def test_real_pty_resize_and_output(self) -> None:
        session = PtySession(["/bin/sh", "-c", "stty size; printf 'PTY_OK\\n'"])
        try:
            session.resize(27, 91)
            deadline = time.monotonic() + 2
            output = bytearray()
            while time.monotonic() < deadline and session.poll() is None:
                output.extend(session.read_available())
                time.sleep(0.01)
            output.extend(session.read_available())
            self.assertIn(b"27 91", output)
            self.assertIn(b"PTY_OK", output)
            self.assertEqual(session.poll(), 0)
        finally:
            session.close()

    def test_focus_key_is_consumed_and_bracketed_paste_is_forwarded(self) -> None:
        router = InputRouter()
        paste = b"\x1b[200~first\nsecond " + "한".encode() + b"\x1b[201~"
        events = router.feed(b"before\x1b[17~" + paste)
        self.assertEqual(events, [b"before", "focus_next", paste])

    def test_bracketed_paste_keeps_literal_ui_key_bytes(self) -> None:
        router = InputRouter()
        paste = b"\x1b[200~" + "한글\n".encode("utf-8") + b"\x1b[17~\x1b[21~\x1b[201~"

        self.assertEqual(router.feed(paste), [paste])

    def test_close_reaps_running_child(self) -> None:
        session = PtySession(["/bin/sh", "-c", "sleep 30"])
        try:
            self.assertIsNone(session.poll())
        finally:
            session.close()
        self.assertIsNotNone(session.poll())

    def test_incomplete_function_key_is_forwarded_after_timeout(self) -> None:
        router = InputRouter()
        self.assertEqual(router.feed(b"\x1b[17", now=1.0), [])
        self.assertEqual(router.flush(now=1.1), [b"\x1b[17"])


if __name__ == "__main__":
    unittest.main()
