import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mkdtemp, rm } from "node:fs/promises";
import net from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { setTimeout as delay } from "node:timers/promises";
import { test } from "node:test";
import workbenchG3Extension from "../../../omp_bridge/g3/bridge.ts";

type Frame = Record<string, any>;
const SESSION_ID = "30000000-0000-4000-8000-000000000001";

async function startBridge() {
	const directory = await mkdtemp(join(tmpdir(), "cw04-g3-test-"));
	const socketPath = join(directory, "bridge.sock");
	const frames: Frame[] = [];
	const sockets: net.Socket[] = [];
	const server = net.createServer(socket => {
		sockets.push(socket);
		let pending = "";
		socket.on("data", chunk => {
			pending += chunk.toString("utf8");
			while (pending.includes("\n")) {
				const index = pending.indexOf("\n");
				frames.push(JSON.parse(pending.slice(0, index)) as Frame);
				pending = pending.slice(index + 1);
			}
		});
	});
	await new Promise<void>((resolve, reject) => {
		server.once("error", reject);
		server.listen(socketPath, resolve);
	});

	const names = ["WORKBENCH_G3_BRIDGE_SOCKET", "WORKBENCH_G3_ROLE", "WORKBENCH_G3_TOKEN", "WORKBENCH_G3_GENERATION"];
	const previous = new Map(names.map(name => [name, process.env[name]]));
	process.env.WORKBENCH_G3_BRIDGE_SOCKET = socketPath;
	process.env.WORKBENCH_G3_ROLE = "worker";
	process.env.WORKBENCH_G3_TOKEN = randomUUID();
	process.env.WORKBENCH_G3_GENERATION = "1";

	const handlers = new Map<string, (...args: any[]) => any>();
	const sent: Array<{ message: string; options: Frame }> = [];
	const state = { idle: true, pending: false, editor: "" as string | undefined };
	let failAfterEnqueue = false;
	let startedTurns = 0;
	const pi = {
		on(name: string, handler: (...args: any[]) => any) { handlers.set(name, handler); },
		async sendUserMessage(message: string, options: Frame) {
			sent.push({ message, options });
			// OMP v18.2.10: omitted deliverAs starts a normal prompt when idle.
			if (state.idle && !("deliverAs" in options)) startedTurns += 1;
			if (failAfterEnqueue) throw new Error("simulated ACK uncertainty after enqueue");
		},
		logger: { error() {} },
	};
	const context = {
		sessionManager: { getSessionId: () => SESSION_ID },
		isIdle: () => state.idle,
		hasPendingMessages: () => state.pending,
		ui: { getEditorText: () => state.editor },
	};
	workbenchG3Extension(pi);
	handlers.get("session_start")!(undefined, context);

	async function waitFor(predicate: (frame: Frame) => boolean, timeoutMs = 1200): Promise<Frame> {
		const deadline = Date.now() + timeoutMs;
		while (Date.now() < deadline) {
			const index = frames.findIndex(predicate);
			if (index >= 0) return frames.splice(index, 1)[0];
			await delay(10);
		}
		throw new Error("bridge frame timed out");
	}

	await waitFor(frame => frame.kind === "hello");
	async function request(frame: Frame): Promise<Frame> {
		const requestId = randomUUID();
		sockets.at(-1)!.write(JSON.stringify({ ...frame, requestId }) + "\n");
		return waitFor(item => item.kind === "api_ack" && item.requestId === requestId);
	}
	async function close(): Promise<void> {
		handlers.get("session_shutdown")?.();
		for (const socket of sockets) socket.destroy();
		await new Promise<void>(resolve => server.close(() => resolve()));
		for (const name of names) {
			const value = previous.get(name);
			if (value === undefined) delete process.env[name];
			else process.env[name] = value;
		}
		await rm(directory, { recursive: true, force: true });
	}
	return {
		frames, sent, state, sockets, handlers, waitFor, request, close,
		get startedTurns() { return startedTurns; },
		setFailAfterEnqueue(value: boolean) { failAfterEnqueue = value; },
	};
}

function envelope(overrides: Frame = {}): Frame {
	return {
		schemaVersion: 1,
		messageId: randomUUID(),
		deliveryAttemptId: randomUUID(),
		senderRole: "manager",
		sessionId: SESSION_ID,
		sessionGeneration: 1,
		taskId: randomUUID(),
		revisionId: randomUUID(),
		runId: randomUUID(),
		event: { type: "message", messageKind: "task", payload: { text: "fixture" } },
		...overrides,
	};
}

test("extension binds role/session and defers busy, pending, approval, and composer states", async () => {
	const bridge = await startBridge();
	try {
		for (const invalid of [
			envelope({ senderRole: "worker" }),
			envelope({ sessionGeneration: 2 }),
			envelope({ sessionId: randomUUID() }),
		]) {
			assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(invalid) })).status, "rejected");
		}
		assert.equal(bridge.sent.length, 0);

		const candidate = envelope();
		bridge.state.idle = false;
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(candidate) })).status, "deferred");
		bridge.state.idle = true;
		bridge.state.pending = true;
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(candidate) })).status, "deferred");
		bridge.state.pending = false;
		bridge.state.editor = "user draft";
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(candidate) })).status, "deferred");
		bridge.state.editor = undefined;
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(candidate) })).status, "deferred");
		bridge.state.editor = "";
		bridge.handlers.get("tool_approval_requested")!({ toolCallId: "A", toolName: "write" });
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(candidate) })).status, "deferred");
		bridge.handlers.get("tool_approval_resolved")!({ toolCallId: "A", toolName: "write", approved: false });
		assert.equal(bridge.sent.length, 0);
	} finally {
		await bridge.close();
	}
});

test("API acceptance stays distinct from model completion and ACK loss never replays", async () => {
	const bridge = await startBridge();
	try {
		const first = envelope();
		const accepted = await bridge.request({ kind: "deliver", envelope: JSON.stringify(first) });
		assert.equal(accepted.status, "api_accepted");
		assert.equal(accepted.modelProcessed, false);
		assert.equal(bridge.sent.length, 1);
		const retry = { ...first, deliveryAttemptId: randomUUID() };
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(retry) })).status, "duplicate_api_accepted");
		assert.equal(bridge.sent.length, 1);

		bridge.setFailAfterEnqueue(true);
		const uncertain = envelope();
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(uncertain) })).status, "unknown_no_replay");
		bridge.setFailAfterEnqueue(false);
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify({ ...uncertain, deliveryAttemptId: randomUUID() }) })).status, "unknown_no_replay");
		assert.equal(bridge.sent.length, 2);
	} finally {
		await bridge.close();
	}
});

test("idle task starts a normal prompt without composer intrusion", async () => {
	const bridge = await startBridge();
	try {
		const response = await bridge.request({ kind: "deliver", envelope: JSON.stringify(envelope()) });
		assert.equal(response.status, "api_accepted");
		assert.equal(response.modelProcessed, false);
		assert.equal(bridge.sent.length, 1);
		assert.equal("deliverAs" in bridge.sent[0].options, false);
		assert.equal(bridge.sent[0].options.attribution, "agent");
		assert.equal(bridge.startedTurns, 1);
		assert.equal(bridge.state.editor, "");
	} finally {
		await bridge.close();
	}
});

test("pause waits for A, blocks B before start, and permits a read tool", async () => {
	const bridge = await startBridge();
	try {
		assert.equal(bridge.handlers.get("tool_call")!({ toolCallId: "A", toolName: "write" }), undefined);
		assert.equal((await bridge.request({ kind: "pause" })).status, "pause_waiting");
		assert.equal(bridge.handlers.get("tool_call")!({ toolCallId: "B", toolName: "edit" }).block, true);
		assert.equal(bridge.handlers.get("tool_call")!({ toolCallId: "R", toolName: "read" }), undefined);
		bridge.handlers.get("tool_execution_end")!({ toolCallId: "A", toolName: "write" });
		await bridge.waitFor(frame => frame.kind === "omp_event" && frame.name === "pause_complete");
		assert.equal(bridge.handlers.get("tool_call")!({ toolCallId: "B2", toolName: "write" }).block, true);
	} finally {
		await bridge.close();
	}
});

test("extension reconnects after transport loss without replaying accepted input", async () => {
	const bridge = await startBridge();
	try {
		const accepted = envelope();
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify(accepted) })).status, "api_accepted");
		bridge.sockets[0].destroy();
		await bridge.waitFor(frame => frame.kind === "hello", 900);
		assert.equal(bridge.sockets.length, 2);
		assert.equal((await bridge.request({ kind: "deliver", envelope: JSON.stringify({ ...accepted, deliveryAttemptId: randomUUID() }) })).status, "duplicate_api_accepted");
		assert.equal(bridge.sent.length, 1);
	} finally {
		await bridge.close();
	}
});

test("session switch rejects a late frame from the previous socket", async () => {
	const bridge = await startBridge();
	try {
		const oldSocket = bridge.sockets[0];
		const nextSessionId = randomUUID();
		const nextContext = {
			sessionManager: { getSessionId: () => nextSessionId },
			isIdle: () => true,
			hasPendingMessages: () => false,
			ui: { getEditorText: () => "" },
		};
		bridge.handlers.get("session_switch")!(undefined, nextContext);
		const staleRequestId = randomUUID();
		oldSocket.write(JSON.stringify({ kind: "probe", requestId: staleRequestId }) + "\n");
		const hello = await bridge.waitFor(frame => frame.kind === "hello" && frame.generation === 2);
		assert.equal(hello.ompSessionId, nextSessionId);
		await delay(60);
		assert.equal(
			bridge.frames.some(frame => frame.kind === "api_ack" && frame.requestId === staleRequestId),
			false,
			"old transport framed a request against the new OMP session",
		);
		assert.equal(
			(await bridge.request({ kind: "deliver", envelope: JSON.stringify(envelope({ sessionId: nextSessionId, sessionGeneration: 2 })) })).status,
			"api_accepted",
		);
	} finally {
		await bridge.close();
	}
});
