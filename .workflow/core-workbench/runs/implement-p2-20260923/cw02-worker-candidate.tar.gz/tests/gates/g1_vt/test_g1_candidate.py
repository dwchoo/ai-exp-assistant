from __future__ import annotations

import os
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

from workbench.terminal.vt_g1.screen import TerminalScreen, make_stream
from workbench.terminal.vt_g1.session import PtySession
from workbench.ui.terminal_g1.input_router import InputRouter


class TerminalScreenTests(unittest.TestCase):
    def test_unicode_truecolor_alt_screen_and_restore(self) -> None:
        screen = TerminalScreen(20, 5)
        stream = make_stream(screen)
        stream.feed("main 가".encode())
        stream.feed(b"\x1b[38;2;107;114;128mC")

        self.assertEqual("".join(screen.buffer[0][x].data for x in range(7)), "main 가")
        self.assertEqual(screen.buffer[0][7].fg, "6b7280")
        stream.feed(b"\x1b[?1049hALT")
        self.assertTrue(screen._terminal_control["using_alternate"])
        self.assertEqual("".join(screen.buffer[0][x].data for x in range(3)), "ALT")
        stream.feed(b"\x1b[?1049l")
        self.assertFalse(screen._terminal_control["using_alternate"])
        self.assertEqual(screen.buffer[0][0].data, "m")

    def test_device_status_cursor_and_device_attribute_replies(self) -> None:
        replies: list[bytes] = []
        screen = TerminalScreen(20, 5, reply=replies.append)
        stream = make_stream(screen)
        stream.feed(b"X\x1b[6n\x1b[c\x1b[5n")

        self.assertEqual(replies, [b"\x1b[1;2R", b"\x1b[?6c", b"\x1b[0n"])

    def test_scrollback_can_page_and_restore(self) -> None:
        screen = TerminalScreen(8, 2, history=20)
        stream = make_stream(screen)
        stream.feed(b"one\r\ntwo\r\nthree\r\nfour\r\n")
        bottom = "".join(screen.buffer[0][x].data for x in range(3))
        screen.prev_page()
        prior = "".join(screen.buffer[0][x].data for x in range(3))
        screen.next_page()
        restored = "".join(screen.buffer[0][x].data for x in range(3))

        self.assertNotEqual(prior, bottom)
        self.assertEqual(restored, bottom)


class PtyAndInputTests(unittest.TestCase):
    def test_real_pty_resize_and_output(self) -> None:
        session = PtySession(["/bin/sh", "-c", "stty size; printf 'PTY_OK\\n'"])
        try:
            session.resize(27, 91)
            deadline = time.monotonic() + 2
            output = bytearray()
            while time.monotonic() < deadline and session.poll() is None:
                output.extend(session.read_available())
                time.sleep(0.01)
            output.extend(session.read_available())
            self.assertIn(b"27 91", output)
            self.assertIn(b"PTY_OK", output)
            self.assertEqual(session.poll(), 0)
        finally:
            session.close()

    def test_focus_key_is_consumed_and_bracketed_paste_is_forwarded(self) -> None:
        router = InputRouter()
        paste = b"\x1b[200~first\nsecond " + "한".encode() + b"\x1b[201~"
        events = router.feed(b"before\x1b[17~" + paste)
        self.assertEqual(events, [b"before", "focus_next", paste])

    def test_incomplete_function_key_is_forwarded_after_timeout(self) -> None:
        router = InputRouter()
        self.assertEqual(router.feed(b"\x1b[17", now=1.0), [])
        self.assertEqual(router.flush(now=1.1), [b"\x1b[17"])


if __name__ == "__main__":
    unittest.main()
