"""Raw-byte host input router; only its documented UI keys are consumed."""
from __future__ import annotations

import time


class InputRouter:
    _keys = {
        b"\x1b[17~": "focus_next",  # xterm F6
        b"\x1b[18~": "scroll_up",  # xterm F7
        b"\x1b[19~": "scroll_down",  # xterm F8
        b"\x1b[21~": "quit",  # xterm F10
    }

    def __init__(self) -> None:
        self._pending = bytearray()
        self._pending_since = 0.0

    def feed(self, data: bytes, *, now: float | None = None) -> list[bytes | str]:
        if data:
            if not self._pending:
                self._pending_since = time.monotonic() if now is None else now
            self._pending.extend(data)
        events: list[bytes | str] = []
        passthrough = bytearray()
        current_time = time.monotonic() if now is None else now

        def flush_passthrough() -> None:
            if passthrough:
                events.append(bytes(passthrough))
                passthrough.clear()

        while self._pending:
            for sequence, action in self._keys.items():
                if self._pending.startswith(sequence):
                    flush_passthrough()
                    del self._pending[: len(sequence)]
                    events.append(action)
                    self._pending_since = current_time
                    break
            else:
                pending_bytes = bytes(self._pending)
                if any(key.startswith(pending_bytes) for key in self._keys):
                    if current_time - self._pending_since < 0.06:
                        break
                passthrough.extend(self._pending[:1])
                del self._pending[:1]
                self._pending_since = current_time
        flush_passthrough()
        return events

    def flush(self, *, now: float | None = None) -> list[bytes | str]:
        return self.feed(b"", now=now)
