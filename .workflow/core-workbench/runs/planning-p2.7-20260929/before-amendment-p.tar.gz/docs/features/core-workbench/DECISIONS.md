# Core 인터뷰 결정 기록

기준일: 2026-09-23. 개별 사용자 답변의 근거다. 전체 [BRIEF](BRIEF.md) 승인 기록은 별도로 관리한다.

- C-D01 / C-D04: 사용자가 `우선 구체화 되어야 하는 것은 'B. 1차 Core Workbench … Phase 2는 후속 …'`이라고 명시했다. 이전 Phase 2 우선 구체화 선택을 대체한다.
- C-D02: 이전 인터뷰의 `2-a` 답변을 유지한다.
- C-D03: 이전 답변에서 Codex CLI가 주력 후보지만 중요도가 낮고 Workbench를 잘 만드는 것이 우선이라고 했다.
- C-D05: 사용자는 프로젝트에 맞는 짧은 AGENTS.md를 요청했다. 상세 workflow는 기존 contract로 연결한다.
- C-D06: 역할·화면 인터뷰의 `1-a` 답변. Manager는 논의·계획·코드 수정, worker는 실험 실행·로그 분석·보고를 맡는다.
- C-D07: 같은 인터뷰의 `2-a` 답변. Manager·worker·terminal 세 영역을 한 화면에 표시한다. 후속 C-D20에서 기존 OMP TUI 재사용 방향을 선택했다.
- C-D08: 실행 정책 인터뷰에서 사용자는 `1-a와c가 좀 섞이면 좋겠는데 어느정도 manager가 알아서 처리`하기를 원했다. 승인과 자율 판단을 결합하는 방향을 채택하며, 구체 정책은 제안과 구분한다.
- C-D09: 최초 worktree 답변은 검토 의향이었다. 후속 C-D12에서 기본 운영 절차와 가이드 적용을 결정했다. 전용 자동 관리·차단 검사와 실행 중 병렬 개발 기능은 아직 승인된 범위가 아니다.
- C-D10: 사용자는 `3-A 사용자가 직접 입력하고 수정도 가능`하기를 원했다. 제어권 인수·worker 자동 입력 정지·반환 후 확인 방향을 채택한다. 실행 중 코드 수정의 경계는 C-D13에서 해결했다.
- C-D11: 후속 답변 `1-a, 그리고 사용자가 허용한 범위 내에서.` 실패 후 코드 수정·재실행까지 허용하되 사용자 허용 범위·예산과 실행 종료 확인을 따른다.
- C-D12: 후속 답변 `2-a, 그런데 가능하면 worker가 코드를 실행할 때는 worktree를 만들어서 실행하는 것을 기준`으로 하기를 원했다. 운영 가이드로 시작하고 commit 기반 실행용 worktree 준비를 기본으로 삼는다.
- C-D13: 후속 답변 `3-a`. 실행 중인 코드·설정을 직접 수정하려면 해당 실험을 먼저 중단한다.
- C-D14: Commit·관측·한도 인터뷰의 `1-a`. Manager가 위임 범위의 local commit을 만들 수 있는 제품 동작에 동의했다. 이는 현재 저장소를 commit하라는 요청이 아니다.
- C-D15: 같은 답변의 `2-a`와 `주기적(1분) 로그를 확인해서 hang이 의심되면 프로세스를 확인하는 작업`. 주기를 1분으로 명시하고 hang 조사를 추가한다.
- C-D16: 같은 답변의 `3-b 시간을 한도로 두지 ... 재시도 횟수 ... 가능하면 자동화 ... 수정 가능하고 개선 가능하다고 제시한 범위에서는 자동`. 작업별 시간 예산 제안을 채택하지 않고 세션 공통 설정·실행 시간 제한 없음·범위 내 자동화를 선택했다.
- C-D17: 모델 호출·hang 처리·재시도 인터뷰의 `1-a`. 매 1분 worker 모델이 새 로그와 상태를 판단한다.
- C-D18: 같은 답변의 `2-a`. Manager가 조사 근거를 검토하고 허용 범위에서 중단·수정·재실행을 결정한다. 불확실하면 조사·사용자 보고를 한다.
- C-D19: 같은 답변의 `3-a`. 세션 공통 설정을 각 작업에 적용하며 기본 자동 복구 재시도는 3회다. 최초 실행·정상 개선 실험과 구분하며 commit 변경만으로 횟수를 초기화하지 않는다.
- C-D20: 화면·종료 인터뷰의 `1-a`. 기존 OMP TUI와 명령을 최대한 유지한다. 구체 결합 방식과 호환 범위는 기술 검증으로 확정한다.
- C-D21: 같은 답변의 `2-a`. 화면만 분리하고 같은 host의 실험·agent·주기 점검은 계속한다. 명시적 전체 종료는 따로 두며 당시 남겨둔 전체 종료·OS 재부팅 정책은 C-D31/C-D32에서 해결했다.
- C-D22: 장애·수동 개입 인터뷰의 `1-a`. 재시작 후 기록·실제 프로세스 대조와 확인 가능한 작업의 자동 복구를 선택했다.
- C-D23: 같은 답변의 `2-a`. 모델 오류 중 실험·로그 수집 유지, 자동 판단·새 명령 일시 정지, 복구 후 상태 확인·재개를 선택했다.
- C-D24: 같은 답변의 `3-a`. 수동 제어 중 detach 시 사용자 제어권을 유지한다.
- C-D25: 같은 답변에서 사용자가 tmux 내부 사용을 거절했다. Workbench를 tmux 또는 herdr 안에서 사용할 예정이며 중첩 multiplexer 문제를 피해야 한다. 외부 프로그램 의존 대신 자체 화면·세션 관리로 구체화한다. 기존 tmux 기반 제안은 철회했다.
- C-D26: OS·호환 범위 인터뷰의 `1-a` 및 `윈도우는 안할꺼야. 맥도 안할 계획이지만 호환을 염두`. Linux만 초기 지원하고 macOS 향후 대응을 고려한다.
- C-D27: 같은 답변의 `2-a`. 텍스트 조작 우선, inline image 후속을 선택했다.
- C-D28: 같은 답변에서 `docs/OMP_Workbench_Development_Spec_v0.3.md` 참조와 `python을 메인으로 개발`을 요청했다. 참고 문서의 정책 표시를 기존 결정 변경이나 현재 구현 승인으로 취급하지 않는다.
- C-D29: 참고 스펙의 분석·peer wake 한도 인터뷰에서 `1-a`. 주기 분석은 고정 횟수 제한 없이 활성 실험 동안 계속하고 사용량 표시·사용자 중지를 제공한다.
- C-D30: 같은 답변의 `2-a`. 정상 manager↔worker 대화에 고정 횟수 제한을 두지 않는다. 위임 범위·재시도 한도·중복 처리 방지는 유지한다.
- C-D31: 종료·재부팅·보존 인터뷰의 `1-a`. 명시적 전체 종료에서 실행 중 작업을 보여주고 사용자 확인 후 중단·정리한다. 사용자 종료를 실패 복구 대상으로 자동 재실행하지 않는다.
- C-D32: 같은 답변의 `2-a`. OS 재부팅 후 기록은 복원하되 환경·실행 조건을 확인하고 사용자가 승인한 뒤 새 실험을 시작한다.
- C-D33: 같은 답변의 `3-a`. 작업·명세·결과 요약은 보존하고 수집 원문 로그는 run당 64 MiB·프로젝트당 512 MiB로 제한한다. 이후 저장 잘림을 표시하며 실행·화면·관측은 계속한다. 실행용 worktree를 자동 삭제하지 않는다. 실험 프로그램의 결과 파일에는 이 로그 한도를 적용하지 않는다.

- C-D34: 자동화 시작·중지·점검 경합 인터뷰의 `1-a`. 사용자가 위임 범위를 승인하며 진행을 지시하면 자동화를 시작한다. 별도의 AUTO ON 조작을 요구하지 않는다.
- C-D35: 같은 답변의 `2-a`. 당시에는 자동화 일시정지 중 기존 실험과 1분 모델 점검·읽기 전용 hang 조사·보고를 유지하고 새 변경·실행을 보류하기로 했다. **일시정지 동작은 후속 C-D49가 대체한다.**
- C-D36: 같은 답변의 `3-a`. Worker의 사용자 대화·작성 중 입력을 우선하고 밀린 주기 점검은 최신 한 건으로 유지한다. 응답 가능한 시점에 점검하고 마지막 점검 시각·지연을 표시한다. 종료 이벤트는 즉시 기록·표시하며 모델 결과 설명은 응답 가능 시 전달한다.

- C-D37: 완료 판단·명세 변경 인터뷰의 `1-a`. Worker가 결과와 검증 근거를 보고하면 manager가 승인된 완료 조건에 대조해 완료를 확정하고 보고한다. 매번 사용자 최종 확인을 요구하지 않으며 근거 부족·조건 모호 시 확인을 요청한다.
- C-D38: 같은 답변의 `2-a`. 실행 중 명세 변경은 기본적으로 다음 실행부터 새 revision으로 적용한다. 현재 실행은 시작 당시 명세를 유지하고 과거 명세·결과를 보존한다. 사용자가 현재 실행에 적용하도록 지시하면 중단·종료 확인 후 수정·재실행한다. 즉시 중단·권한 철회처럼 현재 실행을 명시적으로 제한하는 지시는 즉시 반영한다.

- C-D39: shell 지원·worktree 준비 실패 인터뷰의 `1-a`. 첫 버전은 Linux의 Bash 5.x부터 완성한다. zsh는 후속이며 추가 가능한 구조를 고려한다. 지원하지 않는 shell을 임의로 바꾸지 않고 제한을 표시한다. 기존 Bash/zsh 동시 출시 제안은 대체한다.
- C-D40: 같은 답변의 `2-a`. Worktree 준비 실패는 worker가 원인을 보고하고 manager와 조정해 허용 범위 내 local commit 준비·새 경로 선택 등으로 자동 해결한다. 해결할 수 없거나 추가 권한이 필요하면 사용자에게 묻는다. 사용자 변경을 임의 삭제·stash하거나 개발 중 디렉터리에서 대신 실행하지 않는다. 첫 버전은 일반 도구와 운영 가이드로 적용한다.

- C-D41: 사용자가 `zsh가 설치되어 있어도 bash를 실행해서 할 수 있는거잖아? 그러면 일단 bash만 하는게 좋겠어.`라고 명확히 했다. 기본/login shell이 zsh여도 Workbench의 host terminal은 전용 persistent Bash로 시작한다. 사용자 기본 shell 설정은 변경하지 않는다. 최초 Bash 시작과 실행 오류를 우회하기 위한 매 작업 새 shell 시작은 구분한다. C-D39의 미지원 shell 제한은 기존 기본 shell이 zsh라는 이유로 Workbench 시작을 막는 의미가 아니다.

- C-D42: 사용자가 `bash 혹은 못해도 sh는 지원해야해.`라고 보완했다. Bash 우선, Bash가 없으면 sh로도 Workbench를 사용할 수 있도록 최소 지원 대상으로 포함한다. C-D39/C-D41의 Bash 전용 출시 범위를 확장하며 zsh adapter는 계속 후속이다. 기본/login shell 설정을 바꾸지 않고 전용 persistent shell을 시작한다. sh의 실제 구현별 자동 실행·관측·입력 경합을 검증해야 하며 Bash 시험만으로 sh 지원 완료를 선언하지 않는다.

- C-D43: 남은 운영 정책 네 항목에 대해 사용자가 `추천대로 해줘.`라고 답했다. 1-A: 사용자가 선택한 기존 conda/venv를 재사용한다. Workbench 자체 환경과 분리하며 새 환경 생성·패키지 변경은 위임받은 범위에서만 수행한다. 작업별 환경 생성을 기본으로 강제하지 않는다.
- C-D44: 같은 답변으로 2-A 채택. 당시에는 이미 시작한 현재 도구 작업 완료를 기다린 뒤 다음 변경을 막기로 했다. **후속 C-D49가 이 완료 대기·도구 B 별도 차단 기준을 대체한다.**
- C-D45: 같은 답변으로 3-A 채택. 일반 중단에 반응하지 않으면 강제 종료가 위임 범위에 포함되고 대상 프로세스를 확인할 수 있는 경우에만 manager 판단으로 강제 종료한다. 조건을 충족하지 못하면 사용자에게 묻는다. 중단 응답 대기는 실험 실행 시간 상한과 구분한다.
- C-D46: 같은 답변으로 4-A 채택. 작업 이력의 영속 저장에 실패하면 기존 실험과 가능한 관측은 유지하고 저장 복구까지 새 자동 실행을 보류한다. 원문 로그만 저장에 실패한 경우 누락을 표시하며 실행은 계속한다.

- C-D47: G1 검증 중 사용자가 `2 MiB 한도·전체 거절 (권장)`을 선택했다. Child가 입력을 계속 읽지 않아 queue 공간이 부족하거나 paste가 2 MiB를 넘으면, paste를 일부 전달하지 않고 전체 거절하며 화면에 이유를 표시한다. 이 선택은 정상 크기 paste의 전달·원본 OMP 조작 검증을 면제하지 않는다.
- C-D48: G2 검증 중 사용자가 `명시적 handoff 허용 (권장)`을 선택했다. 사용자가 수동 입력 후 같은 shell에서 `wb-handoff`를 직접 실행해야 자동 실행 재개를 검토한다. 명령 자체가 안전한 clean boundary라는 증거는 아니며 Bash와 sh에서 실제 입력·job·cwd 상태 확인을 통과해야 채택한다.
- C-D49: 사용자가 Core Workbench 자동화 일시정지·worker 역할 정책을 새로 결정해 C-D35/C-D44의 충돌하는 부분보다 우선하도록 지시했다. 일시정지 요청 즉시 새 자동 지시를 보류하고 manager OMP의 진행 중 turn에 Esc와 같은 중단을 요청한다. 도구 A 완료 대기와 준비된 B의 별도 실행 전 차단은 보장하지 않는다. 요청과 실제 중단 확인을 구분하며 마지막 작업·확인된 파일 변경·실행 중 프로세스·미확인 결과를 표시한다. 일시정지 중 manager/worker의 새 자동 모델 작업과 1분 worker 모델 점검은 멈추되 로그·프로세스 수집과 기존 host 실험은 유지한다. 사용자 직접 조사·수정·rollback·명시적 agent 수동 지시는 가능하며 자동 재개를 뜻하지 않는다. Worker가 수정 필요성을 근거와 함께 manager에게 보고하면 그 지시에서의 역할은 끝나며 수정 후 자동으로 같은 작업을 다시 맡지 않는다. 재개 시 실제 파일·도구 결과·프로세스·작업 상태와 승인 범위를 대조하고 중단 명령·대기 요청을 replay하지 않는다. 취소는 기록·결과 파일의 자동 삭제가 아니다. UI 위치는 미결정이다.

- C-D50: 2026-09-24 차단 문제 진단에서 사용자가 `관리된 shell 동작을 보장`을 선택했다. cwd·export·검증된 conda/venv 전환을 지원하고 비호환 hook·trap 변경은 자동 복귀를 보류한다. 같은 사용자 권한의 코드가 Workbench 내부 함수를 고의로 변조하거나 event를 위조하는 공격까지 막는 보안 경계는 요구하지 않는다. 일반적인 입력·job 경합과 상태 불명 시 자동 입력 보류는 계속 검증한다. 기존 실패를 자동으로 통과 처리하는 결정은 아니다.
- C-D51: 같은 진단에서 사용자가 `자동 제어 대기 모드로 전환`을 선택했다. `wb-handoff` 뒤 같은 shell이 prompt로 돌아가지 않고 전용 control 경로에서 명령을 받고 실행하는 방향이다. Shell PID·cwd·환경 보존 요구를 유지한다. 사용자가 제어권을 가져오면 실행 중 실험을 유지하며 안전한 시점에 수동 prompt로 돌아온다. Bash/dash의 실제 구현 가능성은 별도 검증한다.

- C-D52: 같은 진단에서 사용자가 `인수 요청·확인을 구분`을 선택했다. Terminal 인수 요청 즉시 새 자동 전송을 막고, 이미 전달된 명령은 실행 중·종료·미확인으로 표시한다. 실행 중 실험을 유지하며 수동 입력은 확인된 현재 대상에 전달한다. 인수와 상태 확인 뒤 오래된 요청을 자동 재실행하지 않는다. 인수 요청·확인은 이미 전달된 명령의 취소나 종료 보장이 아니다.

- C-D53: 2026-09-24 사용자가 실험 종료 사실과 결과 판단의 책임을 구분했다. Workbench/CW-03은 관리 대상 프로그램의 실제 종료, 확인 가능한 exit status, 로그·결과 파일 위치를 기록하고 불명확하면 unknown으로 둔다. 비정상 exit도 종료가 확인됐다면 종료 사실로 기록한다. Shell 반환만으로 남은 로컬 작업의 종료를 추정하지 않는다. 종료 확인 뒤 worker가 사전 기준에 따라 로그·결과 파일의 출처와 내용을 대조해 성공·실패·판단 보류의 1차 판단 및 미확인을 보고하고, manager가 승인된 완료 조건으로 2차 확인한다. Exit 0만으로 실험 성공을 확정하지 않는다. 실패 복구는 승인 범위와 기존 기본 3회 한도 안에서 manager가 처리하며, 실제 종료 확인 전 소스·설정 수정이나 재실행을 하지 않는다. 수정 필요를 보고한 worker의 기존 지시는 끝나고 재실험에는 새 manager 지시가 필요하다. 해결 불가·한도 도달 시 자동 재시도를 멈추고 근거·시도·남은 문제를 보고한다. 일시정지 중 종료·로그 관측은 계속하되 새 자동 worker 분석은 재개 전 시작하지 않는다. 이 정책은 G2의 수동 입력·정리 결함을 해결한 것으로 보지 않으며 delegated cgroup 필수 여부도 결정하지 않는다.

- C-D54: 2026-09-24 후속 토의에서 사용자는 A 방식을 선택했다. 사용자가 준비한 부모 persistent Bash/sh의 PID·cwd·exported environment와 검증된 conda/venv 상태는 유지한다. 자동 실험 전체는 고정 supervisor/subreaper 아래 별도 interpreter 또는 executable에서 실행하며, 실험 내부 cd·export·source 효과를 부모 shell에 자동 반영하지 않는다. 실험이 만든 관리 대상 후손이 모두 종료·회수됐거나 수명이 `unknown`임을 명시하기 전에는 실험 종료로 확정하지 않는다. Subreaper를 우선 검증하고 수동 준비 단계의 잔존 작업을 소급 관리한다고 가정하지 않는다. 준비된 환경을 사용하며 이번 Docker runtime 검증은 생략하되 container 호환성 목표와 추가 특권 비필수 원칙은 유지한다. 입력 반환 장벽, signal/process group, supervisor 장애 및 수동 작업 관측은 이 결정의 검증 과제이며 이미 해결된 구현으로 간주하지 않는다. 근거는 [로컬 수명 토의 기록](../../../.workflow/core-workbench/notes/2026-09-24-local-lifetime-draft.md)과 [Oracle 검토](../../../.workflow/core-workbench/runs/oracle-review-20260924/REVIEW.md)에 보존한다.

기존 C-D01~C-D46의 개별 결정만으로 전체 BRIEF 승인이나 구현 권한이 생기지는 않았다. C-D47/C-D48은 구현 중 요청한 해당 동작 정책에 대한 사용자 승인이다. C-D49는 사용자가 명시한 후속 정책과 관련 문서 수정·구현 지시다. C-D50~C-D52는 추가 진단 중의 개별 정책 결정이며 당시 개정 BRIEF 전체 승인이나 구현 재개가 아니었다. C-D53은 현재 승인된 구현에 대한 명시적 정책 개정과 문서·검증 반영 지시다. 외부 multiplexer 제약은 [ADR-0001](../../adr/0001-no-external-multiplexer.md), 자동 제어 대기 방향은 [ADR-0002](../../adr/0002-managed-shell-control-wait.md)에 기록한다.

<a id="C-D55"></a>

- C-D55: 2026-09-26 사용자가 개발 호출 예산 증액을 Root에게 위임하고, terminal에서 직접 환경을 준비하며 conda 전용 점검을 제외하도록 결정했다. 자동 실험의 관리 대상 후손 추적, 수동 daemon 소급 관리 비보장, unknown 시 자동 후속 실행 보류, cgroup 비필수 제안에도 동의했다. 기존 구현 승인과 Docker runtime 검증 생략을 유지한다. 부모 cwd·PATH·exported environment의 일반 상속과 입력·signal·수명 검증은 계속 필요하다. 누적 220회와 과거 상한 이력은 보존하고 새 예산은 명시적 전환 뒤 Root가 유한하게 배정한다. 기존 C-D43/C-D50/C-D54의 환경 관리자별 검증 요구와 cgroup 미결정 문구 중 충돌하는 부분을 대체한다. [사용자 발언·적용 범위·다음 세션 절차](DECISION-2026-09-26.md), [승인 record](../../../.workflow/core-workbench/runs/decisions-cd55-20260926/approval.json). 현재 요청은 문서화·인계이며 구현 시작이 아니다.

<a id="C-D56"></a>

- C-D56: 2026-09-29 사용자가 p2.6 최종 gate의 미완료(제품 진입점·backend 유지 detach/reconnect·실제 재부팅 부재)를 닫기 위한 후속 ticket 계획 변경을 승인하고("후속 ticket(plan 변경)은 승인해.", "진행해줘."), 실제 재부팅 검증을 사용자 host가 아닌 격리 VM에서 수행하도록 정했다. VM은 사용자가 apt로 설치한 QEMU/KVM(`qemu-system-x86`, `qemu-utils`, `cloud-image-utils`)과 checksum 검증한 Ubuntu 24.04 cloud image로 구성한다(snap/Multipass 대신 apt 선택). VM 안 OMP 인증은 host의 기존 인증 정보를 복사하도록 지시했다("OMP는 그냥 기존 인증 정보를 복사하도록 해."). 복사한 OAuth refresh token이 교체되면 다른 쪽 로그인이 풀릴 수 있다는 위험은 사용자에게 알렸다. 제품 동작·수락 기준·BRIEF는 바꾸지 않으며 재부팅 뒤 backend 자동 시작은 범위가 아니다. 계획 변경의 최종 bundle 승인은 [p2.7 planning record](../../../.workflow/core-workbench/runs/planning-p2.7-20260929/)의 digest에 연결한다.

<a id="C-D57"></a>

- C-D57: 2026-09-29 사용자가 p2.7 진행 중 UX 검토와 사용성 검토를 계획에 넣도록 지시했다("ux 검토랑 사용성 검토도 넣어줘."). 기존 계획의 UI 검증은 기준 동작의 자동 판정만 다루고, UI 배치·단축키는 BRIEF C-AC-33과 SPEC에서 미결정(구현 중 결정)으로 남아 있었다. 두 사용자 검토 checkpoint를 추가한다. UR-UX는 CW-06 통합 뒤 사용자가 실제 진입점으로 화면 배치·focus/입력 owner 표시·단축키·pane 전환·붙여넣기·detach/재attach·상태 문구를 검토하며, CW-18 dispatch 전에 끝나야 한다. UR-USABILITY는 CW-18 통합 뒤 목표 논의→Task 초안→사용자 승인·진행→실행 관측→인수/handoff→일시정지·재개→완료 보고의 전체 흐름을 사용자가 실제 provider로 사용해 보는 검토이며, CW-16 dispatch 전에 끝나야 한다. 배치·키·문구 수준의 피드백은 해당 ticket(CW-06/CW-18)의 delta로 반영하고 독립 검증을 다시 거친다. 제품 동작·수락 기준을 바꾸는 피드백은 새 결정으로 기록하고 계획 변경을 거친다. 사용자 검토는 자동 gate item을 대체하지 않으며, 자동 gate 통과도 사용자 검토를 대체하지 않는다.

<a id="C-D58"></a>

- C-D58: 2026-09-30 UR-UX(C-D57) 사용자 검토 결과. 사용자 인용: "1. 3열 배치 보다는 상단에 omp 2개, 하단에 터미널 이렇게 해줘. 터미널은 길게 가로로 길게 봐야 하거든. 터미널도 스크롤이 되어야해. 2. (a) 3. 아니 cli로만 되도 될거 같아." (1) 제품 UI 배치: 상단에 manager·worker OMP 두 pane을 나란히, 하단에 host terminal을 전체 폭으로 둔다. Host terminal은 화면 밖으로 지나간 출력을 UI에서 스크롤해 볼 수 있어야 한다. 배치·키 수준이므로 CW-06 delta로 반영하고 독립 검증을 다시 거친다. (2) 사용자 background/suspended job·불명 잔존 등으로 `wb-handoff`가 보류되면 자동 전송·수락 보류는 그대로 유지하되, 사용자는 host 입력 owner로 남거나 인수 요청·확인으로 제어를 되찾아 수동 입력으로 정리한 뒤 다시 `wb-handoff`를 할 수 있어야 한다. 보류가 사용자 입력과 인수까지 막는 막다른 상태를 만들지 않는다(SPEC "사용자가 정리한 뒤 다시 확인한다"의 명확화). CW-18 흐름 조합에서 구현·검증한다. (3) 전체 종료와 재부팅 뒤 `confirm_boot`는 CLI 진입점 명령으로 제공하면 충분하며 제품 UI 안의 조작은 요구하지 않는다(CW-19). UR-UX의 나머지 항목(focus/owner 표시, 단축키, 붙여넣기, detach/재attach, 상태 문구)은 추가 변경 요청이 없었다.

<a id="C-D59"></a>

- C-D59: 2026-09-30 UR-UX 사용 중 사용자 요청. 사용자 인용: "ui/ux 문제 1. manager, worker, 터미널 간에 좌우 창 길이를 조절할 수 있으면 좋겠어. 때에 따라서 어느것은 작고 크게 만들고 싶은데 그게 안돼. Agent 문제 - AGENTS.md나 초기 설정을 wb 용으로 over-write 하지 않으니까 worker를 부를 때 orca skills가 동작해. 즉 wb에서는 다른 시스템 프롬프트가 들어가지 않게 해줘야 여기 내부에서 독자적으로 동작할거 같아." (1) 제품 UI에서 manager·worker 사이 폭과 위 두 OMP·아래 terminal 사이 높이를 사용자가 조절할 수 있어야 한다(배치·키 수준, CW-06 delta). (2) Workbench가 띄우는 두 OMP는 사용자 전역·상위 디렉터리의 주변 설정이 system prompt나 도구로 들어오지 않게 격리한다: 사용자·project skill(예: `~/.agents/skills`의 orca skill, Claude/Codex/Pi 사용자 skill), AGENTS.md·CLAUDE.md 등 context/instruction 파일, rules, 자동 발견 extension·plugin·MCP project 설정·memory 주입을 끈다. Workbench bridge extension(`-e`)과 사용자의 OMP 인증·provider·모델 설정은 그대로 쓰며, credential을 복사·저장하지 않고 사용자의 전역 OMP 설정 파일을 바꾸지 않는다(실행 단위 옵션·overlay로만 적용). Manager·worker 역할 전용 prompt는 이 격리 위에서 CW-18이 제공한다. 이 격리는 CW-17의 "기존 OMP 설정을 그대로 사용한다"를 인증·provider·모델 설정으로 좁히는 변경이다. 끌 수 없는 주입 경로가 확인되면 멈추고 사용자에게 알린다.

<a id="C-D60"></a>

- C-D60: 2026-09-30 UR-UX 사용 중 사용자 결정. 사용자 인용: "그리고 내부에서만 쓸 skills도 필요할거 같아. worker를 호출해서 명령을 내리는. order-worker 이런 식이면 어때?", 선택지 답변: "(나) 승인된 범위 안에서 직접". Workbench는 manager OMP가 worker OMP에게 작업을 지시하는 Workbench 전용 skill(`order-worker`)을 C-D59 격리 위에서 제공한다(`omp_bridge/skills`). 사용자가 승인한 Task 위임 범위([C-AC-29](BRIEF.md) 승인) 안에서는 manager가 지시마다 사용자 승인을 받지 않고 worker에게 바로 지시한다. 승인 범위 밖의 지시는 새 승인을 받는다. 외부 요청 접수는 실행 승인이 아니라는 경계와 manager 승인 명세·worker 실행 보고의 구분은 유지한다. CW-18 범위이며, CW-18 시작 때 ticket·PLAN 변경 기록으로 반영한다. 사용자 전역 skill은 계속 격리한다.

<a id="C-D61"></a>

- C-D61: 2026-09-30 UR-UX 사용 중 사용자 결정. 배경: detach 단축키 `Ctrl-] Ctrl-d`를 쓰다가 prefix 없이 들어간 Ctrl-d로 manager·worker OMP가 모두 정상 종료(exit 0)되었고, 종료된 OMP를 다시 띄울 방법이 없었다. 사용자 인용: "ctrl d가 omp 종료 shortcut이라서 이거 위험성이 커. 지금도 omp가 종료되고 다시 실행이 안돼.", "detach key를 q로 바꿔서 herdr와 통일성을 맞추고 확인 기능도 넣자.", 재시작 시점 답변: "계획대로 CW-19", "그리고 터미널도 강제 종료 기능이 있어야 할거 같아. 강제로 종료하고 다시 자동으로 터미널이 뜨게." (1) 제품 UI의 detach 명령 키를 `d`에서 `q`로 바꾸고(Ctrl 조합 `Ctrl-q`, 메뉴 0은 유지) OMP pane으로 가는 Ctrl-d는 바로 전달하지 않고 확인 뒤 전달한다(배치·키 수준, CW-06 delta). (2) 종료된 manager·worker OMP를 다시 띄우는 기능은 계획대로 CW-19(agent 재시작, C-AC-16)에서 제공한다. (3) 사용자가 host terminal을 강제 종료하면 Workbench가 새 host shell을 자동으로 다시 띄우는 기능을 요구사항에 추가한다. 실행 중 작업·입력 owner·handoff 경계와 기록·실제 process 대조를 지켜야 하므로 CW-19의 재시작 흐름과 함께 제공하며, CW-19 시작 때 ticket·PLAN 변경 기록으로 반영한다. 더 일찍 필요하면 사용자가 다시 정한다.

<a id="C-D62"></a>

- C-D62: 2026-09-30 UR-UX 사용 중 사용자 지시. 사용자 인용: "일단 skills 하기 전에 2가지 문제가 있어. 1. ctrl d로 omp를 종료하면 다시 시작할 방법이 없다. resume으로 다시 시작할 수 있어야 한다. 2. 텍스트 드래그해서 복사할 수 없다. 터미널이나 omp에서 내용 복사가 필요할 때가 많다. 드래그해서 복사할 수 있어야 한다.", 이어서 "1. omp 다시 시작 일단 새로 시작해줘도 resume으로 내가 다시 시작할 수 있으니까 종료됨 enter를 누르면 다시 시작 이렇게 하면 어때? 새로운 세션으로 시작해도 일단은 문제 없을거 같아. 엔터가 가장 좋을거 같고. 2. 드래그 복사 이건 정말 필요해. tmux, herdr에서 복사가 되어야해. 나는 주로 tmux, herdr 안에서 사용할 계획이라 그게 반드시 되어야해." (1) 종료된 manager·worker OMP pane은 "종료됨" 안내를 보여 주고, 사용자가 그 pane에서 Enter를 누르면 새 OMP 세션으로 다시 시작한다. 이전 대화는 사용자가 OMP 안의 resume 기능으로 이어 갈 수 있다. backend와 다른 pane은 그대로 두고, C-D59 격리·bridge 주입·role 인증을 처음 시작과 같게 적용하며 재시작 뒤 격리 확인을 다시 한다. 살아 있는 OMP는 이 조작으로 종료하지 않는다. [C-D61](#C-D61) (2)의 "CW-19에서 제공"을 바꿔 CW-18 전에 CW-17·CW-06 delta로 제공한다. backend 재시작 대조·재부팅 복구와 host terminal 강제 재시작(C-D61 (3))은 CW-19에 남는다. (2) 제품 UI에서 pane 안 텍스트를 마우스 드래그로 선택해 복사할 수 있어야 한다. 선택은 한 pane 안으로 한정하고 스크롤해 보고 있는 과거 출력도 포함하며, 복사는 바깥 terminal의 clipboard로 보낸다(OSC 52). tmux와 herdr 안에서 반드시 동작해야 한다. mouse를 직접 쓰는 pane 프로그램(예: mouse를 켠 vim)에는 지금처럼 mouse를 전달한다. CW-06 delta다. 두 항목 모두 CW-18 시작 전에 독립 test·review를 거쳐 통합한다.

<a id="C-D63"></a>

- C-D63: 2026-10-01 UR-UX 사용 중 사용자 지시. 사용자 인용: "터미널은 ctrl d 로 종료되면 다시 시작 안하네? 그리고 ctrl + ] + 단축키로 터미널을 kill 할 수 있으면 좋겠는데 가능해?", 선택지 답변: 재시작 방식 "Enter로 다시 시작", kill 키 "Ctrl-] k + 확인 (Recommended)", manager 권한일 때 "확인 후 허용 (Recommended)". [C-D61](#C-D61) (3)의 host terminal 강제 종료·재시작을 CW-19에서 앞당겨 CW-18 전에 CW-17·CW-06 delta로 제공한다. (1) host shell이 어떤 이유로든 종료되면(Ctrl-d, exit, 강제 종료) 제품 UI는 종료 안내를 보여 주고, 사용자가 그 pane에서 Enter를 누르면 backend가 새 persistent host shell을 처음 시작과 같은 방식(shell 선택, rcfile·hook, cwd)으로 띄운다. 새 shell의 입력 owner는 사용자이고 control mode·handoff 상태는 새로 시작한다. (2) 사용자는 `Ctrl-] k`(Ctrl 조합·한글 자모 형태 포함)로 host shell 강제 종료를 요청하고, 실행 중인 process가 모두 종료된다는 확인 안내에서 한 번 더 확인해야 실행된다. manager가 입력 owner일 때도 경고를 함께 보인 뒤 확인하면 허용한다. 강제 종료는 host shell과 그 session·job의 process를 종료하며, 스스로 session을 분리한 daemon은 대상이 아니다. 종료 뒤에는 (1)의 Enter 재시작을 따른다. manager가 진행 중이던 host shell 명령은 성공으로 기록하지 않고 결과 불명 또는 실패로 남긴다. backend, OMP pane은 그대로다. backend 재시작 대조·재부팅 복구는 CW-19에 남는다.

<a id="C-D64"></a>

- C-D64: 2026-10-03 UR-UX 종료와 다음 범위에 대한 사용자 지시. 사용자 인용: "일단 UI 적인 것은 괜찮은거 같아. 이제 manager-worker간에 서로 잘 작업을 넘겨주는지 확인하고 skills로 지시를 내릴 수 있게 하는게 중요할거 같아. skills가 아니더라도 mcp/plugin 어떤 것이든 상관 없어. 가장 적합하고 안정적이고 심플한 방법으로 추천해줘. 그리고 wb에서 사용하는 omp는 다른 global 설정이나 skills, agent 등을 보지 않게 해줘. 이 wb 독자적인 설정과 기능으로 돌아가야해. 동시에 omp에도 영향을 줘선 안되고.", 선택지 답변: "인증만 기존 omp에 있는 것을 미러할 수 없을까? ln -s 처럼. 동기화? 이렇게.", "bridge extension 도구를 사용하는데 이름은 to_worker, to_manager 이렇게 간단하게 하는게 더 좋을거 같은데 어때?" (1) UR-UX는 UI 기준으로 종료한다. (2) Workbench가 띄우는 OMP는 Workbench 전용 OMP 홈(`PI_CODING_AGENT_DIR`, data dir 아래)을 써서 사용자 전역 설정·skill·agent·세션·memory를 보지 않고 사용자 `~/.omp`에 기록하지 않는다. 인증만 사용자 OMP 인증 저장소를 symlink로 공유한다(내용 복사·주기 동기화는 OAuth 갱신 회전 때문에 하지 않는다). Workbench는 인증 내용을 읽지 않는다. 적용 전에 실제 OMP로 공유 범위와 무영향을 확인하고, 문제가 있으면 멈추고 다른 방법(OMP auth-broker 등)을 사용자에게 묻는다. C-D59의 overlay 격리는 이 홈 분리로 대체·보강한다. (3) manager↔worker 지시는 이미 주입되는 Workbench bridge extension의 도구 `to_worker`(manager 전용)와 `to_manager`(worker 전용)로 한다. 승인된 Task 범위가 없을 때의 `to_worker`는 제품 UI의 사용자 승인 요청이 되고, 승인된 범위 안의 지시는 바로 전달한다(C-D60). backend가 모든 지시·보고를 기록하고 범위·일시정지를 강제한다. 도구 사용 안내는 Workbench 전용 홈의 skill로 둔다. MCP·plugin은 쓰지 않는다. CW-18 계획의 manager Task 초안 도구는 `to_worker`의 승인 요청으로 합친다(CW-18 시작 시 계획 변경 기록). 실측(p27-home-probe-01, OMP 18.4.5): `agent.db` symlink로 인증이 인식되고 symlink·원본이 유지된다. 홈 분리에는 `PI_CONFIG_DIR`(data dir 아래 config root)와 `PI_CODING_AGENT_DIR`를 함께 쓰고, project 설정이 홈 설정을 덮으므로 C-D59 `--config` overlay를 유지한다. 사용자 결정(2026-10-03): 홈 분리 뒤에도 남는 LSP 설정(`~/.claude/settings.json`·claude plugin LSP, `~/lsp.*`)과 `~/.env` 읽기는 그대로 둔다("그대로 두기"). 사용자에게 OMP 인증 저장소가 없으면 Workbench는 만들지 않고 로그인 안내를 보인다. 사용자 결정(2026-10-03): OMP 브라우저 도구는 상태를 사용자 `~/.omp/browser-state`에 쓰고 위치를 바꿀 수 없으므로 Workbench OMP에서는 끈다("wb에서 브라우저 도구 끄기"). OMP 실행 부품(natives)의 버전별 추출은 문서화된 예외로 둔다(root-adjudication-p27-home-natives).

<a id="C-D65"></a>

- C-D65: 2026-10-03 CW-18 설계(p27-cw18-design-01)에 대한 사용자 결정. 선택지 답변: 일의 범위 "실험 + 자유 작업 둘 다 (Recommended)", host terminal "비어 있을 때만 자동 실행 (Recommended)", skill 이름 "to-manager, to-worker 이게 더 좋아." (1) manager는 `to_worker`로 두 종류의 Task를 맡긴다. 실험 Task는 기존 core 흐름(실행 명령·판정 기준, worker의 실행/보류 판단, host shell 실행, collect/judge, manager 2차 확인)을 그대로 쓴다. 자유 작업 Task는 실행 명령 없이 목표·경로·지시로 이루어지며, worker가 자기 도구로 승인된 경로 안에서 수행하고(분석·코드 수정 포함) `to_manager`로 진행·완료·막힘을 보고한다. 두 종류 모두 첫 지시와 범위 밖 지시는 제품 UI 승인 요청이 되고, 승인된 범위(같은 Task·목표, 승인 경로 안, 실험은 실행 명령·판정 기준·환경 이름·shell이 같고 commit만 다른 재실행) 안의 다음 지시는 바로 전달한다(C-D60). 동시에 활성 Task는 하나다. (2) 승인된 실험 run은 host shell이 사용자 소유의 깨끗한 prompt이고 job이 없을 때만 Workbench가 대신 입력해 시작하고, 아니면 "host terminal 사용 중"으로 보류를 표시한다. (3) Workbench 전용 skill 이름은 도구 이름과 같은 `to-worker`(manager용)와 `to-manager`(worker용)다(C-D60의 `order-worker` 이름을 대체). (4) 자동 검증은 모델 호출 없는 scripted provider로 하고, 실제 모델로 끝까지 확인하는 smoke는 실행 전에 사용자에게 다시 묻는다.

<a id="C-D66"></a>

- C-D66: 2026-10-03 사용자 지시. 사용자 인용: "ui에서 따로 승인할 필요 없이 그냥 manager가 worker에게 지시하면 worker가 수행하면 될거 같아. 대신 manager는 worker가 동시에 1가지 작업만 해야한다는 것을 to_worker 명령어에 넣어서 worker가 작업중이면 작업중이라는 답변을 받게 하면 될거 같은데. 내가 승인 없이 알아서 manager가 worker에게 1가지 작업만 진행하게 해." (1) 사용자는 manager가 worker에게 작업을 맡기는 것을 상시 위임한다. manager의 `to_worker` 지시는 제품 UI 승인 없이 바로 Task가 되어 worker에게 전달되고 수행된다(실험·자유 작업 모두). Task 승인 기록은 이 상시 위임(C-D66)을 근거로 남긴다. 이 결정은 C-AC-29(승인 전 자율 실행 금지)의 승인 시점을 "Task마다 UI 승인"에서 "이 상시 위임"으로 바꾸고, C-D60·C-D65의 승인 범위·UI 승인 요청을 대체한다. (2) worker는 동시에 한 가지 작업만 한다. 진행 중인 Task가 있을 때의 `to_worker`는 큐에 넣지 않고 "worker 작업 중"과 현재 Task 요약을 즉시 돌려준다. worker가 `to_manager`로 완료·막힘을 보고하면 다음 지시를 받는다. 이 규칙은 `to_worker` 도구 설명과 `to-worker` skill에 적는다. (3) 유지되는 안전장치: 실험 run은 host shell이 사용자 소유의 깨끗한 prompt이고 job이 없을 때만 시작한다, pause/resume(reconciled), 재시도 3회, host shell 강제 종료, 모든 지시·보고 기록, 환경 변수 값 거부. 제품 UI는 승인 카드 대신 현재 Task와 worker 상태를 보여 준다.

<a id="C-D67"></a>

- C-D67: 2026-10-05 실제 모델 smoke(p27-cw18-smoke-03) 결과에 대한 사용자 결정. 배경: openai-codex GPT-5.5는 추론 요약이 켜져 있어 worker의 단계 응답(marker 한 줄) 앞에 내용이 보이는 thinking 블록이 붙고, G3 응답 계약의 "thinking 없음" 규칙 때문에 올바른 실행 결정도 거부되었다. 선택지 답변: "A. 판정에서 무시 (Recommended)". worker 단계 응답의 thinking 블록(내용 유무와 관계없이)은 판정에 쓰지 않고 무시하며 기록에도 남기지 않는다. 판정은 정해진 marker 한 줄의 형식·id·결정값만으로 하고, 도구 호출 금지, provider 호출 1회, marker 외 텍스트 금지, 오류·중단 응답 거부, 요청-응답 identity 규칙은 그대로 유지한다. root-adjudication-p27-cw18-empty-thinking의 "빈 thinking만 예외"를 이 결정이 대체한다. 거부 사유는 구체적인 이유로 기록한다.

<a id="C-D68"></a>

- C-D68: 2026-10-05 UR-USABILITY 첫 사용 관찰과 사용자 결정. 사용자 인용: "worker는 omp 내부에서 터미널 명령어를 실행해서 진행했어. 즉 우리 wb의 터미널을 사용하지 않았어. … worker는 터미널을 사용해서 일하게 해야해.", "manager와 worker에 내가 환경설정한 모델이 알아서 설정되면 좋겠어.", "manager는 자유도가 있어야해. 다만 to-worker 스킬을 쓸 때는 강제가 되어야 하고. 그 외에는 manager는 나를 위해 다양한 일을 해줘야해.", "luna는 무조건 max와 fast 모드를 했으면 좋겠어. 나머지 sol은 high 괜찮아.", "worker만 수정하자. worker default luna max fast, slow sol high fast, smol luma xhigh fast, tiny luna high fast". 선택지 답변: "내장 실행 도구 제거 + terminal 도구 (Recommended)", "Workbench 전용 subagent (Recommended)". 관찰: 자유 작업 Task에서 worker가 OMP 내장 `bash`로 명령을 실행했고(`to_manager` 보고는 정상), skill 안내만으로는 강제되지 않는다. (1) Worker OMP는 OMP 내장 명령 실행 도구(`bash`, `eval`)와 OMP 기본 subagent를 쓰지 않는다(OMP `--tools` 허용 목록으로 강제; Workbench bridge 도구는 목록과 무관하게 유지됨을 OMP 18.6.1에서 실측). 파일 조회·수정 도구(read/grep/glob/edit/write)와 web_search·todo는 유지한다. 명령 실행은 Workbench bridge 도구 `terminal`로만 한다: 명령은 host terminal에서 사용자에게 보이게 실행되고 종료 코드와 출력 끝부분을 worker에게 돌려준다. host terminal이 사용자 소유의 깨끗한 prompt이고 job·입력 중이 아닐 때만 실행하고(C-D65 (2)의 규칙), 아니면 실행하지 않고 "host terminal 사용 중"을 돌려준다. 오래 걸리는 명령의 대기·중단 방식과 일시정지 중 동작은 설계 단위에서 정하고 사용자 결정이 필요한 부분은 묻는다. (2) Worker의 subagent는 명령 실행 도구가 없는 Workbench 전용 정의만 쓴다: 조사용(smol 역할)과 고난도 분석·검토용(slow 역할). (3) Manager는 OMP 도구와 OMP 기본 subagent를 그대로 쓴다. 다만 `to_worker`로 맡긴 작업은 manager가 직접 수행하지 않고 worker 보고를 기다린다. 이 규칙은 `to_worker` 도구 설명, `to-worker` skill, `to_worker` 결과 문구에 적는다. (4) 모델(OMP 역할별, provider `openai-codex`, fast = OpenAI `priority` service tier). Manager: default·slow·plan = gpt-6.1-sol high, smol·task·tiny·memory·commit = gpt-6-luna max + fast. Worker: default·task = gpt-6-luna max + fast, slow·plan = gpt-6.1-sol high + fast, smol = gpt-6-luna xhigh + fast, tiny·memory·commit = gpt-6-luna high + fast (사용자가 정하지 않은 plan·task·memory·commit은 Root가 각각 slow·default·tiny에 맞춤). subagent는 자기 역할의 모델을 따른다. 모델표는 Workbench가 소유한 파일 하나에 두고 OMP를 시작할 때마다 적용한다. OMP 안에서 사용자가 `/model` 등으로 바꾸는 것은 그 세션에서 그대로 가능하다. (5) 두 OMP 모두 Codex code mode(도구 호출을 `eval`로 감싸는 방식)를 끈다(`providers.openai-codex.codeMode: off`, 검증된 직접 도구 호출 유지). (6) 격리 확인과 evidence는 현재 설치된 OMP 18.6.1로 다시 만든다. 자동 검증은 모델 호출 없는 scripted provider로 하고 실제 모델 smoke는 실행 전에 사용자에게 묻는다. (7) `terminal` 세부 사용자 결정(2026-10-05, 선택지 답변 "terminal의 현재 위치", "허용 (Recommended)", "새 명령만 거절 (Recommended)", "2분, 최대 30분"): 명령은 host terminal의 현재 위치(사용자가 마지막으로 cd한 곳)에서 실행한다. Task가 없어도 worker는 `terminal`을 쓸 수 있고 기록에는 Task 없음으로 남는다. 일시정지 중에는 새 명령만 거절하고 이미 실행 중인 명령은 계속되며 그 결과를 기다리는 것은 허용한다. 기본 대기 시간은 120초, 최대 1800초이며 시간이 지나도 명령은 계속 돌고 worker가 다시 기다릴 수 있다. OMP 18.6.1 한계: 역할별 fast(service tier) 설정이 없어 fast는 세션과 subagent 단위로만 적용된다(manager 본체의 내부 경량 호출은 fast 없음). 모델표 변경은 Workbench를 다시 시작할 때 반영된다. (8) `terminal` 진행 확인 사용자 결정(2026-10-05). 사용자 인용: "주기적으로 worker에게 점검하라고 시킬 수 없나. 지금 2분 단위로 기다리는건 좋은 방법이 아닌거 같은데." 선택지 답변: 점검 주기 "1분 (Recommended)", 첫 대기 "2분". `terminal` 호출은 결과를 최대 120초 기다리고, 그 안에 끝나지 않으면 "실행 중"을 돌려주며 worker는 다시 기다리는 호출을 반복하지 않고 턴을 끝낸다. 명령이 실행 중인 동안 Workbench는 1분마다 worker에게 점검(명령, 경과 시간, 지난 점검 이후 새 출력)을 보내고, 명령이 끝나면 그 결과를 기다리는 `terminal` 호출이 없을 때 즉시 완료 알림(명령, 종료 코드, 출력 끝부분, 로그 경로)을 보내 worker가 이어서 작업한다. worker가 바쁘면 점검은 최신 한 건으로 병합해 나중에 보내고 완료 알림은 뒤에 전달한다. 일시정지 중에는 점검을 보내지 않고 완료 알림은 재개 때 전달한다. 결과를 다시 받는 `terminal`(명령 없음) 호출은 유지한다. (9) 실제 모델 smoke(p27-cd68-smoke-01)에서 worker가 대기 시간을 180초로 스스로 늘려 (8)의 흐름을 비켜 간 것에 대한 사용자 결정(2026-10-05, 선택지 답변 "120초 고정 (Recommended)"): `terminal`의 대기 시간은 120초로 고정하고 worker가 정하는 대기 시간 입력을 없앤다. (7)의 "최대 1800초"를 이 결정이 대체한다. 같은 smoke의 표시 결함도 고친다: host terminal에 실행한 명령 텍스트가 보여야 하고, worker 명령이 도는 동안 terminal 사용 주체는 worker로 표시한다. (10) 실제 모델 smoke(p27-cd68-smoke-02)에서 worker가 명령 없는 `terminal` 호출로 다시 기다리는 동안 1분 점검이 생략된 것에 대한 사용자 결정(2026-10-06, 선택지 답변 "즉시 응답 (Recommended)"): 명령 없는 `terminal` 호출은 기다리지 않고 현재 상태(실행 중과 지금까지의 출력, 또는 끝난 결과)를 바로 돌려준다. 실행 중인 명령을 기다리는 것은 Workbench의 1분 점검과 완료 알림만 맡는다. (8)의 "결과를 다시 받는 호출 유지"는 이 즉시 응답 형태로 유지한다.

