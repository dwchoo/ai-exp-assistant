"""Independent negative controls for the bounded live TUI delivery probe."""

from __future__ import annotations

import os
import threading
import unittest
from unittest.mock import patch
from uuid import uuid4

import live_tui_draft_probe as probe
from workbench.terminal.vt_g1.screen import TerminalScreen, make_stream


def visible_screen(contents: str) -> TerminalScreen:
    screen = TerminalScreen(100, 30)
    make_stream(screen).feed(contents.encode())
    return screen


class TuiSurfaceTests(unittest.TestCase):
    def test_setup_screen_with_prompt_glyph_is_not_a_ready_composer(self) -> None:
        screen = visible_screen("Setup wizard\r\nπ > Choose a provider")
        state = probe._screen_state(screen, threading.Lock())

        self.assertTrue(state["setup_visible"])
        self.assertFalse(state["composer_visible"])

    def test_old_transcript_draft_does_not_prove_current_composer(self) -> None:
        draft = "draft-from-old-turn"
        screen = visible_screen(f"π >\r\n{draft}\r\nold answer\r\nπ >")
        state = probe._screen_state(screen, threading.Lock(), draft)

        self.assertTrue(state["draft_visible"])
        self.assertTrue(state["composer_visible"])
        self.assertFalse(state["draft_in_composer"])

    def test_visual_draft_remains_visible_after_api_reports_empty(self) -> None:
        draft = "draft-still-painted"
        screen = visible_screen(f"π >\r\n{draft}")
        api_state = {"editorKnown": True, "editorEmpty": True, "idle": True, "pending": False}
        surface = probe._screen_state(screen, threading.Lock(), draft)

        self.assertTrue(api_state["editorEmpty"])
        self.assertTrue(surface["draft_visible"])
        self.assertTrue(surface["draft_in_composer"])


class DeliveryOutcomeTests(unittest.TestCase):
    def _run_case(self, *, draft_stays_visible: bool) -> dict[str, object]:
        class Provider:
            server_port = 12345

            class RequestHandlerClass:
                requests = 0

            semantic_expected: dict[str, object] = {}

            @property
            def semantic_seen(self):
                return {message_id: {"matched": True} for message_id in self.semantic_expected}

            def serve_forever(self):
                pass

            def shutdown(self):
                pass

            def server_close(self):
                pass

        provider = Provider()
        session_id = str(uuid4())

        class Bridge:
            def __init__(self, *_args):
                self.probe_count = 0
                # This event belongs to an older turn; it has no current message ID.
                self.events = [{"role": "worker", "name": "assistant_message_end",
                                "responseMarkerMatched": True}]

            def serve_forever(self):
                pass

            def peer(self, role):
                return {"pid": 900001 if role == "manager" else 900002,
                        "session_id": session_id, "generation": 1}

            def request(self, _target, request, **_kwargs):
                if request["kind"] == "probe":
                    self.probe_count += 1
                    editor_length = 38 if self.probe_count in (2, 3) else 0
                    return {"state": {"editorKnown": True, "editorEmpty": editor_length == 0,
                                      "editorLength": editor_length, "idle": True, "pending": False}}
                if self.probe_count <= 3:
                    return {"status": "deferred"}
                provider.RequestHandlerClass.requests = 1
                return {"status": "api_accepted", "modelProcessed": False}

            def wait_event(self, *_args, **_kwargs):
                return self.events[0]

            def shutdown(self):
                pass

            def server_close(self):
                pass

        # run() generates a "draft-" prefix and a 32-character UUID hex suffix.
        bridge = Bridge()
        # initial screen pair, typed draft, held delivery, then clear or stale paint.
        states = [
            {"composer_visible": True}, {"composer_visible": True},
            {"draft_in_composer": True, "draft_visible": True},
            {"draft_in_composer": True, "draft_visible": True},
        ]
        cleared_screen = {"draft_in_composer": False, "draft_visible": False}
        stale_screen = {"draft_in_composer": True, "draft_visible": True}
        screen_count = 0

        def screen_state(*_args):
            nonlocal screen_count
            screen_count += 1
            if screen_count <= len(states):
                return states[screen_count - 1]
            return stale_screen if draft_stays_visible else cleared_screen
        def start(_omp, role, *_args, **_kwargs):
            fd = os.open(os.devnull, os.O_WRONLY)
            return {"pid": 900001 if role == "manager" else 900002, "fd": fd}

        with (
            patch.object(probe, "semantic_provider", return_value=provider),
            patch.object(probe, "BridgeHarness", return_value=bridge),
            patch.object(probe, "_start_omp", side_effect=start),
            patch.object(probe, "_stop_omps"),
            patch.object(probe, "_drain_visible"),
            patch.object(probe, "_screen_state", side_effect=screen_state),
            patch.object(probe.os, "chmod"),
        ):
            outcome = probe.run("unused-omp")

        return outcome

    def test_api_empty_with_visual_draft_cannot_start_delivery(self) -> None:
        outcome = self._run_case(draft_stays_visible=True)

        self.assertEqual(outcome["result"], "draft_clear_unknown")
        self.assertTrue(outcome["draft_screen_after_clear"]["draft_visible"])
        self.assertEqual(outcome["provider_requests_while_held"], 0)
        self.assertNotIn("api_return_status", outcome)

    def test_unrelated_assistant_marker_cannot_confirm_current_message(self) -> None:
        outcome = self._run_case(draft_stays_visible=False)

        self.assertTrue(outcome["provider_identity_matched"])
        self.assertEqual(outcome["api_return_status"], "api_accepted")
        self.assertNotEqual(outcome["result"], "passed_pair_tui_draft_delivery")


if __name__ == "__main__":
    unittest.main()
