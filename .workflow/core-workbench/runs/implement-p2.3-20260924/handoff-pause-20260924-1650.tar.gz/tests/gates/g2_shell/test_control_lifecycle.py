"""Independent Bash/dash lifecycle observations at the control takeover boundary."""

import os
from pathlib import Path
import shlex
import shutil
import signal
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "src"))

from workbench.terminal.shell_g2.control_probe import ControlWaitProbe
from workbench.terminal.shell_g2.prototype import UnsafeShellState
from tests.gates.g2_shell.test_control_probe import real_shells


class ControlLifecycleTests(unittest.TestCase):
    def enter_wait(self, session: ControlWaitProbe) -> None:
        session.wait_ready()
        session.take_user_control()
        session.send_user(b"wb-handoff\n")
        session.wait_control()

    def recover_manual_prompt(self, session: ControlWaitProbe) -> None:
        recover = getattr(session, "recover_manual_prompt", None)
        self.assertTrue(callable(recover), "no independent manual recovery channel after hold")
        recover()
        session.wait_event("READY", timeout=1)
        self.assertTrue(session.manual_prompt_confirmed)

    def test_foreground_stays_controllable_before_shell_takeover_ack(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "manual-lines"
                with ControlWaitProbe(choice) as session:
                    self.enter_wait(session)
                    session.dispatch_control(
                        "two-lines", f"head -n 2 > {shlex.quote(str(output))}",
                        expected_epoch=session.owner_epoch, generation=session.generation,
                    )
                    session.wait_event("START:two-lines")
                    session.wait_foreground_child()
                    self.assertEqual(session.request_takeover(), "unknown")
                    target = session.confirm_foreground_takeover()
                    self.assertEqual(target.command_id, "two-lines")

                    session.send_confirmed_foreground(b"first\n")
                    session._drain(timeout=0.1)
                    self.assertNotIn(f"TAKEOVER_ACK:{session.pid}", session.events)
                    self.assertFalse(any(e.startswith("DONE:two-lines:") for e in session.events))
                    self.assertEqual(
                        session.confirm_foreground_takeover().process_group,
                        target.process_group,
                    )

                    session.send_confirmed_foreground(b"second\n")
                    self.assertEqual(
                        session.wait_event("EVAL_RETURNED:two-lines:"),
                        "EVAL_RETURNED:two-lines:0",
                    )
                    session.wait_event(f"TAKEOVER_ACK:{session.pid}")
                    if session.delegated:
                        session.wait_event("LOCAL_LIFETIME_DONE:two-lines")
                    else:
                        session.wait_event("LIFETIME_UNKNOWN:two-lines")
                    self.assertFalse(any(e.startswith("DONE:two-lines:") for e in session.events))
                    self.assertEqual(output.read_bytes(), b"first\nsecond\n")
                    with self.assertRaises(UnsafeShellState):
                        session.send_confirmed_foreground(b"late\n")

    def test_foreground_input_spill_never_executes_at_manual_prompt(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "dd-input"
                with ControlWaitProbe(choice) as session:
                    self.enter_wait(session)
                    session.dispatch_control(
                        "six-bytes", f"dd bs=1 count=6 > {shlex.quote(str(output))} 2>/dev/null",
                        expected_epoch=session.owner_epoch, generation=session.generation,
                    )
                    session.wait_event("START:six-bytes")
                    session.wait_foreground_child()
                    self.assertEqual(session.request_takeover(), "unknown")
                    session.confirm_foreground_takeover()
                    session.send_confirmed_foreground(b"first\n__cw_emit SPILL_EXECUTED\n")
                    session.wait_event("EVAL_RETURNED:six-bytes:0")
                    session.wait_event(f"TAKEOVER_ACK:{session.pid}")
                    session.wait_event("READY")
                    deadline = time.monotonic() + 0.5
                    while time.monotonic() < deadline and "SPILL_EXECUTED" not in session.events:
                        session._drain(timeout=0.03)
                    self.assertEqual(output.read_bytes(), b"first\n")
                    self.assertNotIn("SPILL_EXECUTED", session.events)

    def test_control_eof_cannot_release_queued_foreground_input(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "dd-input"
                with ControlWaitProbe(choice) as session:
                    self.enter_wait(session)
                    session.dispatch_control(
                        "eof-six", f"dd bs=1 count=6 > {shlex.quote(str(output))} 2>/dev/null",
                        expected_epoch=session.owner_epoch, generation=session.generation,
                    )
                    session.wait_event("START:eof-six")
                    session.wait_foreground_child()
                    self.assertEqual(session.request_takeover(), "unknown")
                    session.confirm_foreground_takeover()
                    session.send_confirmed_foreground(b"firs")
                    os.close(session._request_fd)
                    session.send_confirmed_foreground(b"t\n__cw_emit EOF_SPILL_EXECUTED\n")
                    deadline = time.monotonic() + 0.5
                    while time.monotonic() < deadline:
                        try:
                            session._drain(timeout=0.03)
                        except OSError:
                            # A queued takeover write may fail after the FD 8 fault.
                            pass
                        if "EOF_SPILL_EXECUTED" in session.events:
                            break
                    self.assertEqual(output.read_bytes(), b"first\n")
                    self.assertNotIn("EOF_SPILL_EXECUTED", session.events)
                    if "READY" in session.events[session.events.index(f"HANDOFF:{session.pid}") + 1:]:
                        self.assertTrue(session.boundary.needs_review)

    def test_ctrl_c_at_control_wait_cannot_silently_restore_prompt(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), ControlWaitProbe(choice) as session:
                self.enter_wait(session)
                before_interrupt = len(session.events)
                os.write(session.master_fd, b"__cw_emit INTERRUPT_SPILL_EXECUTED\n")
                os.write(session.master_fd, b"\x03")
                deadline = time.monotonic() + 0.4
                while time.monotonic() < deadline:
                    session._drain(timeout=0.03)
                later_events = session.events[before_interrupt:]
                self.assertNotIn("INTERRUPT_SPILL_EXECUTED", later_events)
                if "READY" in later_events:
                    self.assertTrue(
                        session.boundary.needs_review,
                        f"Ctrl-C returned to prompt without unknown state: {later_events}",
                    )
                    self.assertFalse(session.manual_prompt_confirmed)

    def test_fd8_eof_after_foreground_wait_can_recover_same_shell(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "dd-input"
                with ControlWaitProbe(choice) as session:
                    session.wait_ready()
                    session.take_user_control()
                    session.send_user(f"cd {shlex.quote(directory)}\n".encode())
                    session.wait_ready()
                    session.send_user(b"export CW03_RECOVERY_VALUE=kept\n")
                    session.wait_ready()
                    session.send_user(b"wb-handoff\n")
                    session.wait_control()
                    original_pid = session.pid

                    session.dispatch_control(
                        "eof-recover", f"dd bs=1 count=6 > {shlex.quote(str(output))} 2>/dev/null",
                        expected_epoch=session.owner_epoch, generation=session.generation,
                    )
                    session.wait_event("START:eof-recover")
                    session.wait_foreground_child()
                    self.assertEqual(session.request_takeover(), "unknown")
                    session.confirm_foreground_takeover()
                    session.send_confirmed_foreground(b"firs")
                    os.close(session._request_fd)
                    session.send_confirmed_foreground(b"t\n__cw_emit RECOVERY_SPILL_EXECUTED\n")
                    deadline = time.monotonic() + 1
                    while "CONTROL_STOPPED" not in session.events and time.monotonic() < deadline:
                        try:
                            session._drain(timeout=0.03)
                        except OSError:
                            # The already queued takeover may hit the closed FD 8 writer.
                            pass
                    self.assertIn("CONTROL_STOPPED", session.events)
                    self.assertIn("EVAL_RETURNED:eof-recover:0", session.events)
                    self.assertEqual(output.read_bytes(), b"first\n")
                    self.assertEqual(session.pid, original_pid)
                    self.assertEqual(os.readlink(f"/proc/{original_pid}/cwd"), directory)
                    self.assertNotIn("READY", session.events[session.events.index("CONTROL_STOPPED"):])
                    self.assertNotIn("RECOVERY_SPILL_EXECUTED", session.events)
                    self.assertFalse(any(e.startswith("DONE:eof-recover:") for e in session.events))

                    self.recover_manual_prompt(session)
                    session.send_user(b"__cw_emit RECOVERY_STATE:$$:$PWD:$CW03_RECOVERY_VALUE\n")
                    self.assertEqual(
                        session.wait_event("RECOVERY_STATE:"),
                        f"RECOVERY_STATE:{original_pid}:{directory}:kept",
                    )
                    self.assertNotIn("RECOVERY_SPILL_EXECUTED", session.events)
                    self.assertEqual(session.events.count("ACCEPT:eof-recover"), 1)

    def test_ctrl_c_hold_can_recover_same_shell_without_queued_input(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                with ControlWaitProbe(choice) as session:
                    session.wait_ready()
                    session.take_user_control()
                    session.send_user(f"cd {shlex.quote(directory)}\n".encode())
                    session.wait_ready()
                    session.send_user(b"export CW03_RECOVERY_VALUE=kept\n")
                    session.wait_ready()
                    session.send_user(b"wb-handoff\n")
                    session.wait_control()
                    original_pid = session.pid

                    os.write(session.master_fd, b"__cw_emit INTERRUPT_RECOVERY_SPILL\n")
                    os.write(session.master_fd, b"\x03")
                    session.wait_event("CONTROL_STOPPED", timeout=1)
                    self.assertIn("CONTROL_INTERRUPTED", session.events)
                    self.assertEqual(os.readlink(f"/proc/{original_pid}/cwd"), directory)
                    self.assertNotIn("INTERRUPT_RECOVERY_SPILL", session.events)
                    self.assertNotIn("READY", session.events[session.events.index("CONTROL_STOPPED"):])

                    self.recover_manual_prompt(session)
                    session.send_user(b"__cw_emit RECOVERY_STATE:$$:$PWD:$CW03_RECOVERY_VALUE\n")
                    self.assertEqual(
                        session.wait_event("RECOVERY_STATE:"),
                        f"RECOVERY_STATE:{original_pid}:{directory}:kept",
                    )
                    self.assertNotIn("INTERRUPT_RECOVERY_SPILL", session.events)

    def test_background_work_survives_takeover_without_done(self) -> None:
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "background-result"
                script = f"(sleep 0.4; printf finished > {shlex.quote(str(output))}) &"
                with ControlWaitProbe(choice) as session:
                    self.enter_wait(session)
                    session.dispatch_control(
                        "background-work", script,
                        expected_epoch=session.owner_epoch, generation=session.generation,
                    )
                    session.wait_event("START:background-work")
                    self.assertEqual(
                        session.wait_event("ACTIVE_JOBS:background-work"),
                        "ACTIVE_JOBS:background-work",
                    )
                    session.wait_event("EVAL_RETURNED:background-work:0")
                    self.assertEqual(session.request_takeover(), "unknown")
                    session.wait_event(f"TAKEOVER_ACK:{session.pid}")
                    self.assertFalse(any(e.startswith("DONE:background-work:") for e in session.events))
                    deadline = time.monotonic() + 2
                    while time.monotonic() < deadline:
                        if output.exists() and output.read_text() == "finished":
                            break
                        session._drain(timeout=0.03)
                    self.assertEqual(output.read_text(), "finished")
                    if session.delegated:
                        session.wait_event("LOCAL_LIFETIME_DONE:background-work")
                    else:
                        session.wait_event("LIFETIME_UNKNOWN:background-work")
                    self.assertFalse(any(e.startswith("DONE:background-work:") for e in session.events))

    def test_reparented_daemon_is_not_reported_done_while_alive(self) -> None:
        if shutil.which("setsid") is None:
            self.skipTest("setsid unavailable")
        for choice in real_shells():
            with self.subTest(shell=choice.kind), tempfile.TemporaryDirectory() as directory:
                pid_file = Path(directory) / "escaped-pid"
                daemon_pid = None
                try:
                    with ControlWaitProbe(choice) as session:
                        self.enter_wait(session)
                        script = (
                            "setsid sh -c 'sleep 1.2 & echo $! > "
                            f"{shlex.quote(str(pid_file))}' >/dev/null 2>&1 & "
                            f"while [ ! -s {shlex.quote(str(pid_file))} ]; "
                            "do sleep 0.01; done; wait"
                        )
                        session.dispatch_control(
                            "escaped", script,
                            expected_epoch=session.owner_epoch, generation=session.generation,
                        )
                        session.wait_event("RETURN:escaped:")
                        self.assertTrue(pid_file.exists())
                        daemon_pid = int(pid_file.read_text().strip())
                        with open(f"/proc/{daemon_pid}/status", encoding="ascii") as stream:
                            status = stream.read()
                        self.assertNotIn("State:\tZ", status)
                        self.assertNotEqual(os.getsid(daemon_pid), session.pid)
                        self.assertFalse(
                            any(e.startswith("DONE:escaped:") for e in session.events),
                            f"escaped PID {daemon_pid} remains alive; events={session.events}",
                        )
                        session.wait_control()
                        if session.delegated:
                            self.assertTrue(session._populated(session.run_cgroup))
                            session.wait_event("LOCAL_WORK_ACTIVE:escaped")
                            session.wait_event("LOCAL_LIFETIME_DONE:escaped", timeout=2)
                            self.assertFalse(session._populated(session.run_cgroup))
                        else:
                            session.wait_event("LIFETIME_UNKNOWN:escaped")
                        self.assertFalse(
                            any(e.startswith("DONE:escaped:") for e in session.events),
                            f"async work must not become DONE; events={session.events}",
                        )
                finally:
                    if daemon_pid is not None:
                        try:
                            os.kill(daemon_pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass


if __name__ == "__main__":
    unittest.main()
