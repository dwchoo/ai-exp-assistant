"""Bounded two-process OMP TUI draft and identified delivery feasibility probe."""

from __future__ import annotations

import json
import os
import errno
from pathlib import Path
import select
import shutil
import tempfile
import threading
import time
from uuid import uuid4

from live_omp_probe import (
    BridgeHarness, OMP_VERSION, _omp_version,
    _start_omp, _stop_omps,
)
from live_rpc_pause_probe import semantic_provider

from workbench.contracts.v1 import ActorRole, ControlEnvelope, MessageEvent, MessageKind


def _drain_visible(fd: int, stop: threading.Event, result: dict[str, object]) -> None:
    """Drain PTY and retain only byte counts and an ephemeral draft visibility flag."""
    tail = b""
    result["bytes"] = 0
    result["draft_rendered"] = False
    result["draft_prefix_rendered"] = False
    result["error_indicator"] = False
    while not stop.is_set():
        try:
            if not select.select([fd], [], [], 0.1)[0]:
                continue
            chunk = os.read(fd, 65536)
            if not chunk:
                return
            result["bytes"] = int(result["bytes"]) + len(chunk)
            needle = result.get("draft_needle")
            if isinstance(needle, bytes):
                combined = tail + chunk
                if needle in combined:
                    result["draft_rendered"] = True
                if b"draft-" in combined:
                    result["draft_prefix_rendered"] = True
                if b"Error" in combined or b"error" in combined:
                    result["error_indicator"] = True
                tail = combined[-max(len(needle) - 1, 0):]
        except OSError as exc:
            if exc.errno != errno.EIO:
                result["error"] = exc.errno
            return


def run(omp: str) -> dict[str, object]:
    result: dict[str, object] = {"result": "inconclusive", "mode": "two-real-tui"}
    with tempfile.TemporaryDirectory(prefix="cw04-g3-tui-draft-") as temporary:
        root = Path(temporary)
        socket_path = root / "bridge.sock"
        config = root / "config.yml"
        config.write_text("# Isolated TUI probe overlay.\n")
        profile = root / "agent"
        profile.mkdir()
        provider = semantic_provider(manager=False)
        provider_thread = threading.Thread(target=provider.serve_forever, daemon=True)
        provider_thread.start()
        (profile / "models.yml").write_text(
            "providers:\n"
            "  g3-tui-probe:\n"
            f"    baseUrl: http://127.0.0.1:{provider.server_port}/v1\n"
            "    api: openai-completions\n"
            "    auth: none\n"
            "    models:\n"
            "      - id: scripted\n"
            "        name: Scripted G3 TUI probe\n"
            "        contextWindow: 32768\n"
            "        maxTokens: 1024\n"
        )
        roles = ("manager", "worker")
        tokens = {role: str(uuid4()) for role in roles}
        server = BridgeHarness(socket_path, tokens)
        os.chmod(socket_path, 0o600)
        server_thread = threading.Thread(target=server.serve_forever, daemon=True)
        server_thread.start()
        children: list[dict[str, object]] = []
        drains: list[tuple[threading.Thread, threading.Event, dict[str, object]]] = []
        try:
            for role in roles:
                child = _start_omp(
                    omp, role, tokens[role], root, socket_path, config,
                    profile=profile, model="g3-tui-probe/scripted", max_time="45",
                    expected_marker="Pair probe response." if role == "worker" else None,
                )
                children.append(child)
                stop = threading.Event()
                drained: dict[str, object] = {"role": role}
                thread = threading.Thread(
                    target=_drain_visible, args=(int(child["fd"]), stop, drained), daemon=True,
                )
                thread.start()
                drains.append((thread, stop, drained))
            peers = {role: server.peer(role) for role in roles}
            result["pids"] = [int(peers[role]["pid"]) for role in roles]
            if len(set(result["pids"])) != 2:
                raise RuntimeError("two distinct OMP processes were not observed")

            target = "worker"
            initial = server.request(target, {"kind": "probe"})["state"]
            result["initial_state"] = {
                key: initial.get(key) for key in ("idle", "pending", "editorKnown", "editorEmpty", "editorLength")
            }
            time.sleep(1)
            draft = f"draft-{uuid4().hex}"
            drains[1][2]["draft_needle"] = draft.encode()
            for char in draft.encode():
                os.write(int(children[1]["fd"]), bytes((char,)))
                time.sleep(0.01)
            draft_state = None
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                state = server.request(target, {"kind": "probe"})["state"]
                if state.get("editorLength") == len(draft):
                    draft_state = state
                    break
                time.sleep(0.35)
            result["draft_state"] = {
                key: state.get(key) for key in ("idle", "pending", "editorKnown", "editorEmpty", "editorLength")
            }
            result["draft_visible_to_extension"] = draft_state is not None
            result["draft_rendered_in_tui"] = drains[1][2]["draft_rendered"]
            result["draft_prefix_rendered_in_tui"] = drains[1][2]["draft_prefix_rendered"]
            drains[1][2].pop("draft_needle", None)
            result["provider_requests_with_draft"] = provider.RequestHandlerClass.requests
            if draft_state is None:
                os.write(int(children[1]["fd"]), b"\r")
                deadline = time.monotonic() + 5
                while time.monotonic() < deadline and provider.RequestHandlerClass.requests == 0:
                    time.sleep(0.1)
                result["manual_draft_submit_reached_provider"] = provider.RequestHandlerClass.requests > 0
                result["result"] = (
                    "composer_api_draft_unobservable" if result["manual_draft_submit_reached_provider"]
                    else "tui_input_path_unknown"
                )
                return result

            message_id = str(uuid4())
            peer = peers[target]
            envelope = ControlEnvelope(
                message_id=message_id,
                delivery_attempt_id=str(uuid4()),
                sender_role=ActorRole.MANAGER,
                session_id=str(peer["session_id"]),
                session_generation=int(peer["generation"]),
                task_id=str(uuid4()), revision_id=str(uuid4()), run_id=str(uuid4()),
                event=MessageEvent(MessageKind.TASK, {"text": "Reply briefly. Do not use tools."}),
            )
            provider.semantic_expected[message_id] = {
                "workbench_message_id": message_id, "kind": "task",
                "task_id": envelope.task_id, "revision_id": envelope.revision_id,
                "run_id": envelope.run_id,
            }
            held = server.request(target, {"kind": "deliver", "envelope": envelope.to_json()})
            result["draft_delivery_status"] = held.get("status")
            result["draft_length_after_deliver"] = server.request(target, {"kind": "probe"})["state"].get("editorLength")
            result["provider_requests_while_held"] = provider.RequestHandlerClass.requests
            if held.get("status") != "deferred" or result["draft_length_after_deliver"] != len(draft):
                result["result"] = "draft_not_preserved"
                return result

            os.write(int(children[1]["fd"]), b"\x7f" * len(draft))
            deadline = time.monotonic() + 5
            cleared = None
            while time.monotonic() < deadline:
                state = server.request(target, {"kind": "probe"})["state"]
                if state.get("editorKnown") and state.get("editorEmpty") and state.get("idle") and not state.get("pending"):
                    cleared = state
                    break
                time.sleep(0.1)
            result["draft_cleared_safely"] = cleared is not None
            if cleared is None:
                result["result"] = "draft_clear_unknown"
                return result

            start = time.monotonic()
            response = server.request(target, {"kind": "deliver", "envelope": envelope.to_json()}, timeout=8)
            result["api_return_status"] = response.get("status")
            result["api_model_processed_flag"] = response.get("modelProcessed")
            result["api_return_elapsed_ms"] = round((time.monotonic() - start) * 1000)
            try:
                server.wait_event(target, "agent_end", timeout=20)
                result["agent_end_observed"] = True
            except TimeoutError:
                result["agent_end_observed"] = False
            result["provider_requests"] = provider.RequestHandlerClass.requests
            result["provider_identity_matched"] = provider.semantic_seen.get(message_id, {}).get("matched") is True
            result["assistant_marker_matched"] = any(
                event.get("role") == target and event.get("name") == "assistant_message_end"
                and event.get("responseMarkerMatched") is True
                for event in server.events
            )
            result["result"] = "passed_pair_tui_draft_delivery" if (
                result["api_return_status"] == "api_accepted"
                and result["provider_requests_with_draft"] == 0
                and result["provider_requests_while_held"] == 0
                and result["provider_identity_matched"]
                and result["assistant_marker_matched"]
                and result["agent_end_observed"]
            ) else "inconclusive"
            return result
        finally:
            _stop_omps(children)
            result["omp_children_remaining"] = sum(Path(f"/proc/{child['pid']}").exists() for child in children)
            for thread, stop, drained in drains:
                stop.set()
                thread.join(timeout=1)
            result["pty_drain"] = [drained for _, _, drained in drains]
            for child in children:
                os.close(int(child["fd"]))
            server.shutdown()
            server.server_close()
            server_thread.join(timeout=2)
            provider.shutdown()
            provider.server_close()
            provider_thread.join(timeout=2)


if __name__ == "__main__":
    omp = shutil.which("omp")
    if not omp or _omp_version(omp) != OMP_VERSION:
        raise SystemExit("requires OMP 18.2.10")
    outcome = run(omp)
    print(json.dumps(outcome, sort_keys=True))
    raise SystemExit(0 if outcome["result"] == "passed_pair_tui_draft_delivery" else 1)
